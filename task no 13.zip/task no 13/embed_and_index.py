"""
embed_and_index.py
------------------
Embeds all cleaned questions using HuggingFace MiniLM
and stores the vectors in a FAISS index.

Run once before starting the Flask app:
    python embed_and_index.py
"""

import json
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from preprocess import load_and_preprocess, save_processed

# ── Config ────────────────────────────────────────────────────────────────────
MODEL_NAME   = "sentence-transformers/all-MiniLM-L6-v2"
INDEX_PATH   = "faiss_index.bin"
METADATA_PATH = "processed_qa.json"
# ──────────────────────────────────────────────────────────────────────────────


def build_index():
    # 1. Preprocess
    data = load_and_preprocess("qa_data.json")
    save_processed(data, METADATA_PATH)

    # 2. Load MiniLM model
    print(f"[Embed] Loading model: {MODEL_NAME}")
    model = SentenceTransformer(MODEL_NAME)

    # 3. Embed cleaned questions
    questions = [item["clean_question"] for item in data]
    print(f"[Embed] Embedding {len(questions)} questions …")
    embeddings = model.encode(questions, show_progress_bar=True, convert_to_numpy=True)

    # Normalize vectors for cosine similarity via inner product
    faiss.normalize_L2(embeddings)

    # 4. Build FAISS index (Inner Product = cosine similarity after L2 norm)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    print(f"[FAISS] Index built — {index.ntotal} vectors, dimension {dim}.")

    # 5. Save index
    faiss.write_index(index, INDEX_PATH)
    print(f"[FAISS] Index saved to '{INDEX_PATH}'.")


if __name__ == "__main__":
    build_index()
