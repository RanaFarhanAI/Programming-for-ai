"""
preprocess.py
-------------
Loads qa_data.json, cleans and normalizes the text,
then saves a processed version ready for embedding.
"""

import json
import re


def clean_text(text: str) -> str:
    """Lowercase, strip extra whitespace, remove special characters."""
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)          # collapse multiple spaces
    text = re.sub(r"[^\w\s\?\.\,\-\']", "", text)  # keep basic punctuation
    return text


def load_and_preprocess(path: str = "qa_data.json") -> list[dict]:
    """
    Load raw QnA pairs and return a cleaned list of dicts:
      { "question": ..., "answer": ..., "clean_question": ... }
    """
    with open(path, "r", encoding="utf-8") as f:
        raw_data = json.load(f)

    processed = []
    for idx, item in enumerate(raw_data):
        processed.append({
            "id": idx,
            "question": item["question"],
            "answer": item["answer"],
            # We embed the cleaned question for better similarity matching
            "clean_question": clean_text(item["question"]),
        })

    print(f"[Preprocess] Loaded and cleaned {len(processed)} QnA pairs.")
    return processed


def save_processed(data: list[dict], out_path: str = "processed_qa.json"):
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"[Preprocess] Saved processed data to '{out_path}'.")


if __name__ == "__main__":
    data = load_and_preprocess()
    save_processed(data)
