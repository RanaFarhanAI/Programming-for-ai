# Semantic QnA Bot — University Admissions

A Flask-based chatbot that answers university admission queries using a full NLP pipeline:
**Preprocess → MiniLM Embeddings → FAISS Vector Search → Flask UI**

---

## Pipeline Overview

```
User Query
    │
    ▼
[1] Preprocess (lowercase, clean)
    │
    ▼
[2] Embed with HuggingFace MiniLM (all-MiniLM-L6-v2)
    │
    ▼
[3] FAISS Similarity Search (cosine similarity)
    │
    ▼
[4] Return best matching answer
    │
    ▼
[5] Display in Flask + WhatsApp-style UI
```

---

## Project Structure

```
project/
├── app.py                  # Flask backend + search logic
├── embed_and_index.py      # Build FAISS index (run once)
├── preprocess.py           # Text cleaning utilities
├── qa_data.json            # Raw QnA dataset (50 pairs)
├── processed_qa.json       # Cleaned QnA (auto-generated)
├── faiss_index.bin         # FAISS index (auto-generated)
├── requirements.txt
├── static/
│   ├── script.js           # Frontend chat logic
│   └── style.css           # WhatsApp-style dark UI
└── templates/
    └── index.html          # Chat UI template
```

---

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Build the FAISS index (run once)
```bash
python embed_and_index.py
```
This will:
- Clean and preprocess `qa_data.json`
- Embed all questions using MiniLM
- Save the FAISS index to `faiss_index.bin`

### 3. Start the Flask app
```bash
python app.py
```

### 4. Open in browser
```
http://localhost:5000
```

---

## How It Works

| Step | File | Description |
|------|------|-------------|
| Preprocess | `preprocess.py` | Lowercase, strip whitespace, remove special chars |
| Embed | `embed_and_index.py` | MiniLM encodes each question into a 384-dim vector |
| Index | `embed_and_index.py` | FAISS `IndexFlatIP` stores L2-normalized vectors for cosine similarity |
| Search | `app.py → search()` | Query is embedded, FAISS returns nearest neighbour |
| Threshold | `app.py` | If similarity < 0.40, returns a fallback message |
| UI | `templates/`, `static/` | WhatsApp-style dark chat interface |

---

## Dataset

50 QnA pairs covering:
- Programs: BS AI, BS CS, BS IT, BS SE, BS Data Science
- Universities: FAST, UMT, Superior, UOL, Punjab University
- Topics: fees, eligibility, deadlines, scholarships, entry tests, scope, hostel

---

## Extending

### Add more QnA pairs
Edit `qa_data.json`, then re-run:
```bash
python embed_and_index.py
```

### Adjust similarity threshold
In `app.py`:
```python
THRESHOLD = 0.40   # lower = more permissive, higher = stricter
```

### Return top-3 answers
In `app.py`:
```python
TOP_K = 3
```
