"""
app.py
------
Flask backend for the Semantic QnA Bot.
Pipeline: User query → MiniLM embed → FAISS search → return best answer.
"""

import json
import re
import numpy as np
import faiss
from flask import Flask, render_template, request, jsonify
from sentence_transformers import SentenceTransformer

# ── Config ────────────────────────────────────────────────────────────────────
MODEL_NAME    = "sentence-transformers/all-MiniLM-L6-v2"
INDEX_PATH    = "faiss_index.bin"
METADATA_PATH = "processed_qa.json"
TOP_K         = 1          # number of nearest neighbours to retrieve
THRESHOLD     = 0.40       # minimum cosine similarity to return an answer
# ──────────────────────────────────────────────────────────────────────────────

app = Flask(__name__)

# ── Load model + index at startup ─────────────────────────────────────────────
print("[App] Loading MiniLM model …")
model = SentenceTransformer(MODEL_NAME)

print("[App] Loading FAISS index …")
index = faiss.read_index(INDEX_PATH)

print("[App] Loading QnA metadata …")
with open(METADATA_PATH, "r", encoding="utf-8") as f:
    qa_data = json.load(f)

print(f"[App] Ready — {index.ntotal} QnA pairs indexed.")
# ──────────────────────────────────────────────────────────────────────────────


def clean_query(text: str) -> str:
    """Same cleaning applied during indexing."""
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\w\s\?\.\,\-\']", "", text)
    return text


def search(query: str) -> dict:
    """
    Embed the query, search FAISS, return the best matching QnA pair
    along with its similarity score.
    """
    clean = clean_query(query)
    vec = model.encode([clean], convert_to_numpy=True)
    faiss.normalize_L2(vec)

    scores, indices = index.search(vec, TOP_K)
    best_score = float(scores[0][0])
    best_idx   = int(indices[0][0])

    if best_score < THRESHOLD:
        return {
            "answer": (
                "I'm not sure about that. Try asking about programs, fees, "
                "eligibility, deadlines, or scholarships at FAST, UMT, "
                "Superior, UOL, or Punjab University."
            ),
            "matched_question": None,
            "score": best_score,
        }

    matched = qa_data[best_idx]
    return {
        "answer": matched["answer"],
        "matched_question": matched["question"],
        "score": best_score,
    }


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index_page():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(force=True)
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"reply": "Please type a question."})

    result = search(user_message)
    reply  = result["answer"]

    # Optionally surface the matched question for transparency
    if result["matched_question"]:
        confidence = int(result["score"] * 100)
        reply += f"\n\n_(Matched: \"{result['matched_question']}\" — {confidence}% confidence)_"

    return jsonify({"reply": reply})


# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True)
