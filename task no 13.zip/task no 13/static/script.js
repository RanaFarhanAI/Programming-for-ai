// script.js — Frontend chat logic for Semantic QnA Bot

const chatBox  = document.getElementById("chat-box");
const inputEl  = document.getElementById("user-input");

/* ── Helpers ──────────────────────────────────────────────────────────────── */

/**
 * Append a message bubble to the chat box.
 * @param {string} text  - Message content (supports basic markdown: *italic*, _italic_)
 * @param {"user"|"bot"} role
 * @returns {HTMLElement} the created element
 */
function appendMessage(text, role) {
  const div = document.createElement("div");
  div.classList.add("message", role);
  div.innerHTML = formatText(text);
  chatBox.appendChild(div);
  scrollToBottom();
  return div;
}

/**
 * Very lightweight markdown-ish formatter:
 *   _text_  → <em>text</em>
 *   "quoted" → styled quote
 */
function formatText(text) {
  // Escape HTML first
  let safe = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  // _italic_ or *italic*
  safe = safe.replace(/[_*](.*?)[_*]/g, "<em>$1</em>");

  // Newlines → <br>
  safe = safe.replace(/\n/g, "<br>");

  return safe;
}

function scrollToBottom() {
  chatBox.scrollTop = chatBox.scrollHeight;
}

function showTyping() {
  const el = document.createElement("div");
  el.classList.add("typing");
  el.id = "typing-indicator";
  el.textContent = "Bot is typing…";
  chatBox.appendChild(el);
  scrollToBottom();
  return el;
}

function removeTyping() {
  const el = document.getElementById("typing-indicator");
  if (el) el.remove();
}

/* ── Core send function ───────────────────────────────────────────────────── */

async function sendMessage() {
  const message = inputEl.value.trim();
  if (!message) return;

  // Show user bubble & clear input
  appendMessage(message, "user");
  inputEl.value = "";
  inputEl.focus();

  // Show typing indicator
  showTyping();

  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();
    removeTyping();
    appendMessage(data.reply, "bot");

  } catch (err) {
    removeTyping();
    appendMessage("⚠️ Could not reach the server. Please try again.", "bot");
    console.error("Fetch error:", err);
  }
}

/* ── Events ───────────────────────────────────────────────────────────────── */

// Enter key sends message
inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Welcome message on load
window.addEventListener("load", () => {
  appendMessage(
    "👋 Hi! I'm your University Admission Assistant.\n\n" +
    "Ask me anything about:\n" +
    "• Programs (BS AI, BS CS, BS IT, BS SE)\n" +
    "• Fees & scholarships\n" +
    "• Eligibility criteria\n" +
    "• Admission deadlines\n" +
    "• FAST, UMT, Superior, UOL, Punjab University\n\n" +
    "Type your question below!",
    "bot"
  );
});
