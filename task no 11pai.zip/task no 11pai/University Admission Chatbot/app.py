from flask import Flask, render_template, request, jsonify
import json
import re

app = Flask(__name__)

# Load data
with open("data.json") as f:
    data = json.load(f)

aliases = {
    "umt": "UMT",
    "superior": "Superior",
    "superior uni": "Superior",
    "uol": "UOL",
    "lahore university": "UOL",
    "university of lahore": "UOL"
}
# Memory
last_university = None


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    global last_university

    user_message = request.json["message"].lower()

    # ======================
    # 1. Recommendation
    # ======================
    if "suggest" in user_message or "recommend" in user_message:
        return jsonify({"reply": "Recommendation feature working..."})

    # ======================
    # 2. University detection
    # ======================
    for key in aliases:
        if key in user_message:
            last_university = aliases[key]
            return jsonify({
                "reply": f"{last_university} selected. Ask about programs, eligibility, fee, or deadline."
            })

    for uni in data:
        if uni.lower() in user_message:
            last_university = uni
            return jsonify({
                "reply": f"{uni} selected. Ask about programs, eligibility, fee, or deadline."
            })

    # ======================
    # 3. CONTEXT REQUIRED
    # ======================
    if last_university:
        uni_data = data[last_university]

        # 🔥 PROGRAM DETAILS (FIXED)
        if "bs" in user_message:
            for program in uni_data["programs"]:
                if program.lower() in user_message:

                    details = uni_data.get("details", {}).get(program)

                    if details:
                        return jsonify({
                            "reply": f"""
📘 {program} Details ({last_university})

⏳ Duration: {details['duration']}

📚 Subjects:
- {', '.join(details['subjects'])}

💼 Scope:
{details['scope']}
"""
                        })
                    else:
                        return jsonify({"reply": f"No details available for {program}."})

            return jsonify({"reply": "Program not found."})

        # ======================
        # 4. FEE (PROGRAM-WISE)
        # ======================
        elif "fee" in user_message:

            found_program = None

            for program in uni_data["programs"]:
                if program.lower() in user_message:
                    found_program = program
                    break

            if found_program:
                fee = uni_data["fees"].get(found_program, "Not available")
                return jsonify({
                    "reply": f"Fee for {found_program} at {last_university}: {fee}"
                })

            else:
                fee_list = "\n".join([
                    f"{p}: {uni_data['fees'][p]}" for p in uni_data["fees"]
                ])
                return jsonify({
                    "reply": f"Fee structure for {last_university}:\n{fee_list}"
                })

        # ======================
        elif "deadline" in user_message:
            return jsonify({
                "reply": f"Deadline for {last_university}: {uni_data['deadline']}"
            })

        elif "eligibility" in user_message:
            return jsonify({
                "reply": f"Eligibility: {uni_data['eligibility']}"
            })

        elif "program" in user_message:
            return jsonify({
                "reply": f"Programs: {', '.join(uni_data['programs'])}"
            })

        else:
            return jsonify({
                "reply": f"Ask about programs, eligibility, fee, or deadline for {last_university}"
            })

    # ======================
    # 4. DEFAULT RESPONSE
    # ======================
    return jsonify({
        "reply": "Please mention a university first (FAST, UMT, Superior, UOL, PU)."
    })
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)