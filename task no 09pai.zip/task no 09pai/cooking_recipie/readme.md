# 🍳 Recipe App (Flask)

## Features
- Recipe search using API
- Login & Signup system
- Favorites system
- Admin panel (add recipes)
- AJAX search (no reload)

## Technologies
- Flask
- SQLite
- HTML/CSS/JS
- API (TheMealDB)

## How to Run
pip install -r requirements.txt
python app.py