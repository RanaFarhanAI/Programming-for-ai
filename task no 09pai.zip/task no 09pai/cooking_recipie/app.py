from flask import Flask, render_template, request, redirect, session, jsonify
import requests
import sqlite3

app = Flask(__name__)
app.secret_key = "secret123"

# -------------------------------
# DATABASE SETUP
# -------------------------------
def init_db():
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()

    # Users
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT
    )
    """)

    # Favorites
    cur.execute("""
    CREATE TABLE IF NOT EXISTS favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        recipe_id TEXT
    )
    """)

    # Custom Recipes
    cur.execute("""
    CREATE TABLE IF NOT EXISTS custom_recipes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        image TEXT,
        instructions TEXT
    )
    """)

    conn.commit()
    conn.close()

init_db()

# -------------------------------
# HOME
# -------------------------------
@app.route("/")
def home():
    return render_template("index.html", user=session.get("user"))

# -------------------------------
# API SEARCH (AJAX)
# -------------------------------
@app.route("/api/search", methods=["POST"])
def api_search():
    data = request.get_json()
    query = data.get("query")

    recipes = get_recipes(query)

    if not recipes:
        recipes = []

    # ✅ ADD THESE LINES HERE
    print("Query:", query)
    print("Recipes:", recipes)

    return jsonify(recipes)

# -------------------------------
# GET RECIPES FROM API
# -------------------------------
def get_recipes(query):
    url = f"https://www.themealdb.com/api/json/v1/1/search.php?s={query}"
    return requests.get(url).json().get("meals")

# -------------------------------
# RECIPE DETAIL + SIMILAR
# -------------------------------
@app.route("/recipe/<id>")
def recipe_detail(id):

    # Custom recipe
    if id.startswith("custom_"):
        rid = id.split("_")[1]

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM custom_recipes WHERE id=?", (rid,))
        r = cur.fetchone()
        conn.close()

        if not r:
            return "Recipe not found"

        recipe = {
            "idMeal": id,
            "strMeal": r[1],
            "strMealThumb": r[2],
            "strInstructions": r[3],
            "strCategory": "Custom",
            "strArea": "User"
        }
        similar = []

    else:
        url = f"https://www.themealdb.com/api/json/v1/1/lookup.php?i={id}"
        data = requests.get(url).json()

        recipe = data.get("meals")
        if not recipe:
            return "Recipe not found"

        recipe = recipe[0]

        # Similar recipes
        category = recipe["strCategory"]
        url = f"https://www.themealdb.com/api/json/v1/1/filter.php?c={category}"
        similar = requests.get(url).json().get("meals", [])[:4]

    return render_template("recipe.html",
                           recipe=recipe,
                           similar=similar,
                           user=session.get("user"))

# -------------------------------
# FAVORITE
# -------------------------------
@app.route("/favorite/<id>")
def add_favorite(id):
    if "user" not in session:
        return redirect("/login")

    username = session["user"]

    conn = sqlite3.connect("database.db")
    cur = conn.cursor()

    # prevent duplicate
    cur.execute("SELECT * FROM favorites WHERE username=? AND recipe_id=?", (username, id))
    if not cur.fetchone():
        cur.execute("INSERT INTO favorites (username, recipe_id) VALUES (?, ?)", (username, id))
        conn.commit()

    conn.close()
    return redirect("/")

# -------------------------------
# VIEW FAVORITES
# -------------------------------
@app.route("/favorites")
def favorites():
    if "user" not in session:
        return redirect("/login")

    username = session["user"]

    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("SELECT recipe_id FROM favorites WHERE username=?", (username,))
    ids = cur.fetchall()
    conn.close()

    recipes = []

    for r in ids:
        rid = r[0]

        if rid.startswith("custom_"):
            cid = rid.split("_")[1]

            conn = sqlite3.connect("database.db")
            cur = conn.cursor()
            cur.execute("SELECT * FROM custom_recipes WHERE id=?", (cid,))
            rec = cur.fetchone()
            conn.close()

            if rec:
                recipes.append({
                    "idMeal": rid,
                    "strMeal": rec[1],
                    "strMealThumb": rec[2]
                })

        else:
            url = f"https://www.themealdb.com/api/json/v1/1/lookup.php?i={rid}"
            data = requests.get(url).json()
            meal = data.get("meals")
            if meal:
                recipes.append(meal[0])

    return render_template("favorites.html", recipes=recipes, user=username)

# -------------------------------
# ADMIN PANEL
# -------------------------------
@app.route("/admin", methods=["GET", "POST"])
def admin():

    # 🔐 Only admin allowed
    if session.get("user") != "admin":
        return "Access denied ❌"

    if request.method == "POST":
        title = request.form["title"]
        image = request.form["image"]
        instructions = request.form["instructions"]

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO custom_recipes (title, image, instructions) VALUES (?, ?, ?)",
            (title, image, instructions)
        )
        conn.commit()
        conn.close()

        return redirect("/admin")

    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM custom_recipes")
    recipes = cur.fetchall()
    conn.close()

    return render_template("admin.html", recipes=recipes)

# -------------------------------
# AI GENERATOR
# -------------------------------
@app.route("/generate", methods=["POST"])
def generate():
    ingredients = request.form.get("ingredients")

    recipe = f"""
    Recipe using {ingredients}:
    1. Mix ingredients
    2. Cook for 20 minutes
    3. Serve hot 🍽️
    """

    return render_template("ai_recipe.html", recipe=recipe)

# -------------------------------
# SIGNUP
# -------------------------------
@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        cur.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("signup.html")

# -------------------------------
# LOGIN
# -------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect("database.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cur.fetchone()
        conn.close()

        if user:
            session["user"] = username
            return redirect("/")
        else:
            return "Invalid credentials ❌"

    return render_template("login.html")

# -------------------------------
# LOGOUT
# -------------------------------
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/")

# -------------------------------
# RUN
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)