"""
Facial Feature Measurement Module
Measures and analyzes facial features based on landmarks
"""
import numpy as np
from typing import List, Tuple, Dict
import math

class FeatureMeasurement:
    def __init__(self, landmarks: List[Tuple[int, int]]):
        """
        Initialize with facial landmarks
        
        Args:
            landmarks: List of 68 facial landmarks
        """
        self.landmarks = landmarks
        self.measurements = {}
        self._calculate_measurements()
    
    @staticmethod
    def distance(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
        """Calculate Euclidean distance between two points"""
        return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)
    
    @staticmethod
    def angle(p1: Tuple[float, float], p2: Tuple[float, float], p3: Tuple[float, float]) -> float:
        """
        Calculate angle at p2 formed by p1-p2-p3
        Returns angle in degrees
        """
        v1 = (p1[0] - p2[0], p1[1] - p2[1])
        v2 = (p3[0] - p2[0], p3[1] - p2[1])
        
        cos_angle = (v1[0]*v2[0] + v1[1]*v2[1]) / (
            math.sqrt(v1[0]**2 + v1[1]**2) * math.sqrt(v2[0]**2 + v2[1]**2) + 1e-6
        )
        cos_angle = max(-1, min(1, cos_angle))
        return math.degrees(math.acos(cos_angle))
    
    def _calculate_measurements(self):
        """Calculate all facial feature measurements"""
        if len(self.landmarks) != 68:
            return
        
        # Eye measurements
        self.measurements['left_eye_width'] = self.distance(self.landmarks[36], self.landmarks[39])
        self.measurements['left_eye_height'] = (
            self.distance(self.landmarks[37], self.landmarks[41]) +
            self.distance(self.landmarks[38], self.landmarks[40])
        ) / 2
        
        self.measurements['right_eye_width'] = self.distance(self.landmarks[42], self.landmarks[45])
        self.measurements['right_eye_height'] = (
            self.distance(self.landmarks[43], self.landmarks[47]) +
            self.distance(self.landmarks[44], self.landmarks[46])
        ) / 2
        
        # Eye distance
        self.measurements['eye_distance'] = self.distance(self.landmarks[36], self.landmarks[45])
        
        # Nose measurements
        self.measurements['nose_length'] = self.distance(self.landmarks[27], self.landmarks[34])
        self.measurements['nose_width'] = self.distance(self.landmarks[31], self.landmarks[35])
        
        # Mouth measurements
        self.measurements['mouth_width'] = self.distance(self.landmarks[48], self.landmarks[54])
        self.measurements['mouth_height'] = (
            self.distance(self.landmarks[51], self.landmarks[57]) +
            self.distance(self.landmarks[50], self.landmarks[56])
        ) / 2
        
        # Jawline measurements
        jaw_length = self.distance(self.landmarks[4], self.landmarks[14])
        self.measurements['jaw_length'] = jaw_length
        
        # Calculate jaw shape ratio (width relative to length)
        jaw_width_upper = self.distance(self.landmarks[0], self.landmarks[16])
        self.measurements['jaw_width'] = jaw_width_upper
        self.measurements['jaw_ratio'] = jaw_width_upper / (jaw_length + 1e-6)
        
        # Facial proportions
        face_height = self.distance(self.landmarks[27], self.landmarks[8])
        self.measurements['face_height'] = face_height
        self.measurements['face_width'] = jaw_width_upper
        self.measurements['face_ratio'] = jaw_width_upper / (face_height + 1e-6)
        
        # Eye shape ratios
        self.measurements['left_eye_ratio'] = self.measurements['left_eye_height'] / (self.measurements['left_eye_width'] + 1e-6)
        self.measurements['right_eye_ratio'] = self.measurements['right_eye_height'] / (self.measurements['right_eye_width'] + 1e-6)
        
        # Eyebrow angles
        left_eyebrow = self.landmarks[17:22]
        right_eyebrow = self.landmarks[22:27]
        
        self.measurements['left_eyebrow_angle'] = self.angle(left_eyebrow[0], left_eyebrow[2], left_eyebrow[4])
        self.measurements['right_eyebrow_angle'] = self.angle(right_eyebrow[0], right_eyebrow[2], right_eyebrow[4])
        
        # Mouth shape
        self.measurements['mouth_ratio'] = self.measurements['mouth_height'] / (self.measurements['mouth_width'] + 1e-6)
    
    def get_measurements(self) -> Dict[str, float]:
        """Return all measurements"""
        return self.measurements.copy()
    
    def get_normalized_measurements(self) -> Dict[str, float]:
        """
        Return normalized measurements (0-1 scale)
        Used for personality profiling
        """
        if not self.measurements:
            return {}
        
        normalized = {}
        
        # Normalize based on typical ranges
        normalized['eye_openness'] = min(1.0, self.measurements['left_eye_ratio'] / 0.5)
        normalized['eye_spacing'] = min(1.0, self.measurements['eye_distance'] / 100)
        
        normalized['nose_prominence'] = min(1.0, self.measurements['nose_length'] / 50)
        normalized['nose_width_ratio'] = self.measurements['nose_width'] / (self.measurements['nose_length'] + 1e-6)
        
        normalized['mouth_size'] = min(1.0, self.measurements['mouth_width'] / 60)
        normalized['mouth_fullness'] = self.measurements['mouth_ratio']
        
        normalized['jaw_angularity'] = 1.0 - min(1.0, self.measurements['jaw_ratio'])
        normalized['face_shape'] = self.measurements['face_ratio']
        
        normalized['eyebrow_angle'] = min(1.0, (self.measurements['left_eyebrow_angle'] + self.measurements['right_eyebrow_angle']) / 360)
        
        return normalized
    
    def get_summary(self) -> Dict[str, str]:
        """Get human-readable summary of measurements"""
        summary = {}
        
        m = self.measurements
        
        # Eye summary
        eye_openness = self.measurements['left_eye_ratio']
        if eye_openness > 0.4:
            summary['eyes'] = "Wide and open"
        elif eye_openness > 0.25:
            summary['eyes'] = "Moderately open"
        else:
            summary['eyes'] = "Narrow eyes"
        
        # Nose summary
        nose_ratio = m['nose_width'] / (m['nose_length'] + 1e-6)
        if nose_ratio > 0.5:
            summary['nose'] = "Wider nose"
        elif nose_ratio > 0.3:
            summary['nose'] = "Moderate nose"
        else:
            summary['nose'] = "Narrow nose"
        
        # Mouth summary
        if m['mouth_ratio'] > 0.5:
            summary['mouth'] = "Full lips"
        elif m['mouth_ratio'] > 0.25:
            summary['mouth'] = "Moderate lips"
        else:
            summary['mouth'] = "Thin lips"
        
        # Jaw summary
        if m['jaw_ratio'] > 0.5:
            summary['jaw'] = "Square jaw"
        elif m['jaw_ratio'] > 0.4:
            summary['jaw'] = "Heart-shaped face"
        else:
            summary['jaw'] = "Oval/elongated face"
        
        return summary
