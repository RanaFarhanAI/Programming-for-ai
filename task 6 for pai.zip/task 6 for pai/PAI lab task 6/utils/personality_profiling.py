"""
16 Personality Types Profiling Based on Facial Features
Maps facial measurements to MBTI personality types
"""
from typing import Dict, Tuple

class PersonalityProfiler:
    """
    Maps facial features to 16 personality types (MBTI)
    Based on psychological research correlating facial features with personality
    """
    
    # MBTI personality type descriptions
    PERSONALITY_TYPES = {
        'ISTJ': {
            'name': 'The Logistician',
            'traits': ['Responsible', 'Practical', 'Logical', 'Organized', 'Detail-oriented'],
            'description': 'Practical and fact-oriented individuals with strong organizational skills'
        },
        'ISFJ': {
            'name': 'The Defender',
            'traits': ['Protective', 'Warm', 'Loyal', 'Duty-conscious', 'Observant'],
            'description': 'Warm-hearted and dedicated individuals who take their commitments seriously'
        },
        'INFJ': {
            'name': 'The Counselor',
            'traits': ['Insightful', 'Principled', 'Passionate', 'Creative', 'Compassionate'],
            'description': 'Thoughtful and introspective individuals driven by their values'
        },
        'INTJ': {
            'name': 'The Architect',
            'traits': ['Strategic', 'Ambitious', 'Independent', 'Analytical', 'Determined'],
            'description': 'Natural leaders who excel at strategic thinking and planning'
        },
        'ISTP': {
            'name': 'The Virtuoso',
            'traits': ['Practical', 'Realistic', 'Analytical', 'Direct', 'Action-oriented'],
            'description': 'Flexible and practical individuals who enjoy hands-on problem solving'
        },
        'ISFP': {
            'name': 'The Adventurer',
            'traits': ['Sensitive', 'Creative', 'Flexible', 'Artistic', 'Loyal'],
            'description': 'Artistic and sensitive individuals who live in the moment'
        },
        'INFP': {
            'name': 'The Mediator',
            'traits': ['Idealistic', 'Poetic', 'Introspective', 'Open-minded', 'Creative'],
            'description': 'Idealistic individuals who focus on possibilities and meaning'
        },
        'INTP': {
            'name': 'The Logician',
            'traits': ['Logical', 'Analytical', 'Independent', 'Creative', 'Truth-seeking'],
            'description': 'Logical and innovative thinkers absorbed in ideas'
        },
        'ESTP': {
            'name': 'The Entrepreneur',
            'traits': ['Energetic', 'Smart', 'Flexible', 'Bold', 'Action-oriented'],
            'description': 'Smart and energetic individuals who enjoy being the center of attention'
        },
        'ESFP': {
            'name': 'The Entertainer',
            'traits': ['Outgoing', 'Spontaneous', 'Fun-loving', 'Playful', 'Practical'],
            'description': 'Outgoing and spontaneous individuals who bring joy to social gatherings'
        },
        'ENFP': {
            'name': 'The Campaigner',
            'traits': ['Enthusiastic', 'Creative', 'Spontaneous', 'Charismatic', 'Optimistic'],
            'description': 'Enthusiastic and imaginative individuals with infectious enthusiasm'
        },
        'ENTP': {
            'name': 'The Debater',
            'traits': ['Intellectual', 'Curious', 'Quick-witted', 'Flexible', 'Innovative'],
            'description': 'Innovative and inventive thinkers who love intellectual challenges'
        },
        'ESTJ': {
            'name': 'The Executive',
            'traits': ['Practical', 'Realistic', 'Organized', 'Responsible', 'Logical'],
            'description': 'Natural leaders who are practical and fact-oriented'
        },
        'ESFJ': {
            'name': 'The Consul',
            'traits': ['Conscientious', 'Friendly', 'Organized', 'Outgoing', 'Supportive'],
            'description': 'Conscientious and helpful individuals who care about others'
        },
        'ENFJ': {
            'name': 'The Protagonist',
            'traits': ['Charismatic', 'Inspiring', 'Responsible', 'Passionate', 'Visionary'],
            'description': 'Charismatic individuals with a strong sense of responsibility'
        },
        'ENTJ': {
            'name': 'The Commander',
            'traits': ['Strategic', 'Ambitious', 'Commanding', 'Efficient', 'Logical'],
            'description': 'Strategic and ambitious leaders with a commanding presence'
        }
    }
    
    def __init__(self, normalized_measurements: Dict[str, float]):
        """
        Initialize with normalized facial measurements
        
        Args:
            normalized_measurements: Dictionary of normalized (0-1) facial measurements
        """
        self.measurements = normalized_measurements
        self.personality_type = None
        self.confidence = 0.0
        self.profile = {}
        self._calculate_personality()
    
    def _calculate_personality(self):
        """Calculate personality type based on facial features"""
        # Extract measurement values (with defaults if missing)
        m = self.measurements
        
        eye_openness = m.get('eye_openness', 0.5)
        eye_spacing = m.get('eye_spacing', 0.5)
        eyebrow_angle = m.get('eyebrow_angle', 0.5)
        mouth_fullness = m.get('mouth_fullness', 0.5)
        jaw_angularity = m.get('jaw_angularity', 0.5)
        face_shape = m.get('face_shape', 0.5)
        nose_prominence = m.get('nose_prominence', 0.5)
        
        # Calculate MBTI dimensions based on facial features
        
        # Extraversion (E) vs Introversion (I)
        # Wide-set eyes, open eyes, expressive features indicate extraversion
        extraversion_score = (eye_spacing + eye_openness + eyebrow_angle) / 3
        is_extraverted = extraversion_score > 0.5
        
        # Sensing (S) vs Intuition (N)
        # Angular features, defined jawline indicate sensing
        # Softer features, larger eyes indicate intuition
        sensing_score = (jaw_angularity + nose_prominence) / 2
        is_sensing = sensing_score > 0.5
        
        # Thinking (T) vs Feeling (F)
        # Angular jawline, closer-set eyes indicate thinking
        # Softer features, wide-set eyes indicate feeling
        thinking_score = jaw_angularity + (1 - face_shape) / 2
        thinking_score = thinking_score / 1.5
        is_thinking = thinking_score > 0.5
        
        # Judging (J) vs Perceiving (P)
        # Defined features and eyebrows indicate judging
        # Softer features indicate perceiving
        judging_score = jaw_angularity + eyebrow_angle / 2
        judging_score = judging_score / 1.5
        is_judging = judging_score > 0.5
        
        # Construct personality type
        personality = ""
        personality += "E" if is_extraverted else "I"
        personality += "S" if is_sensing else "N"
        personality += "T" if is_thinking else "F"
        personality += "J" if is_judging else "P"
        
        self.personality_type = personality
        
        # Calculate confidence (how strong the signals are)
        confidence = (
            abs(extraversion_score - 0.5) * 2 +
            abs(sensing_score - 0.5) * 2 +
            abs(thinking_score - 0.5) * 2 +
            abs(judging_score - 0.5) * 2
        ) / 4
        self.confidence = min(1.0, confidence)
        
        # Get personality profile
        self.profile = self.PERSONALITY_TYPES.get(personality, {})
    
    def get_personality_type(self) -> str:
        """Return the 4-letter MBTI type"""
        return self.personality_type
    
    def get_confidence(self) -> float:
        """Return confidence score (0-1)"""
        return self.confidence
    
    def get_full_profile(self) -> Dict:
        """Return complete personality profile"""
        return {
            'type': self.personality_type,
            'name': self.profile.get('name', 'Unknown'),
            'traits': self.profile.get('traits', []),
            'description': self.profile.get('description', ''),
            'confidence': f"{self.confidence * 100:.1f}%"
        }
    
    def get_recommendations(self) -> Dict[str, str]:
        """Get personality-based recommendations"""
        mbti_type = self.personality_type
        
        recommendations = {
            'strengths': self._get_strengths(mbti_type),
            'growth_areas': self._get_growth_areas(mbti_type),
            'communication_style': self._get_communication_style(mbti_type),
            'work_preferences': self._get_work_preferences(mbti_type)
        }
        
        return recommendations
    
    @staticmethod
    def _get_strengths(mbti_type: str) -> str:
        strengths_map = {
            'I': 'Focus, depth, introspection',
            'E': 'Breadth, socializability, action-orientation'
        }
        
        if mbti_type[0] in strengths_map:
            return strengths_map[mbti_type[0]]
        return "Unique strengths"
    
    @staticmethod
    def _get_growth_areas(mbti_type: str) -> str:
        growth_map = {
            'I': 'Expanding social connections, initiating interactions',
            'E': 'Deep listening, contemplation'
        }
        
        if mbti_type[0] in growth_map:
            return growth_map[mbti_type[0]]
        return "Personal growth areas"
    
    @staticmethod
    def _get_communication_style(mbti_type: str) -> str:
        comm_map = {
            'I': 'Thoughtful listener, prefers written communication',
            'E': 'Engaging speaker, enjoys discussion',
            'S': 'Practical, concrete, fact-based',
            'N': 'Imaginative, theory-focused, big-picture oriented',
            'T': 'Logical, objective, direct',
            'F': 'Empathetic, harmony-seeking, values-driven'
        }
        
        style = []
        if mbti_type[0] in comm_map:
            style.append(comm_map[mbti_type[0]])
        if mbti_type[1] in comm_map:
            style.append(comm_map[mbti_type[1]])
        
        return " + ".join(style) if style else "Unique communication style"
    
    @staticmethod
    def _get_work_preferences(mbti_type: str) -> str:
        work_map = {
            'E': 'Team collaboration, variety, external engagement',
            'I': 'Independent work, depth, focused projects',
            'J': 'Structure, planning, organized systems',
            'P': 'Flexibility, spontaneity, adaptability'
        }
        
        prefs = []
        if mbti_type[0] in work_map:
            prefs.append(work_map[mbti_type[0]])
        if mbti_type[3] in work_map:
            prefs.append(work_map[mbti_type[3]])
        
        return " + ".join(prefs) if prefs else "Flexible work preferences"
