"""
test_utils.py
-------------
Unit tests for utility functions.
"""

import os
import json
import pytest

from src.utils import (
    export_chat_history,
    export_to_markdown,
    clean_text,
    truncate,
    is_supported_file,
    get_file_size_mb,
)


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_history():
    return [
        {
            "question": "What is AI?",
            "answer": "AI stands for Artificial Intelligence.",
            "sources": [{"source": "doc.pdf", "chunk_index": 0, "chunk": "AI is..."}],
            "confidence": {"score": 85, "label": "High", "flags": []}
        },
        {
            "question": "What is ML?",
            "answer": "ML is Machine Learning, a subset of AI.",
            "sources": [],
            "confidence": {"score": 60, "label": "Medium", "flags": []}
        }
    ]


# ─── Tests: export_chat_history ───────────────────────────────────────────────

def test_export_json_creates_file(sample_history, tmp_path):
    path = str(tmp_path / "history.json")
    result = export_chat_history(sample_history, output_path=path)
    assert os.path.exists(result)


def test_export_json_valid_content(sample_history, tmp_path):
    path = str(tmp_path / "history.json")
    export_chat_history(sample_history, output_path=path)
    with open(path) as f:
        data = json.load(f)
    assert len(data) == 2
    assert data[0]["question"] == "What is AI?"


def test_export_json_auto_filename(sample_history, tmp_path):
    os.chdir(tmp_path)
    path = export_chat_history(sample_history)
    assert path.endswith(".json")
    assert os.path.exists(path)
    os.remove(path)


# ─── Tests: export_to_markdown ────────────────────────────────────────────────

def test_export_markdown_creates_file(sample_history, tmp_path):
    path = str(tmp_path / "history.md")
    result = export_to_markdown(sample_history, output_path=path)
    assert os.path.exists(result)


def test_export_markdown_contains_questions(sample_history, tmp_path):
    path = str(tmp_path / "history.md")
    export_to_markdown(sample_history, output_path=path)
    with open(path) as f:
        content = f.read()
    assert "What is AI?" in content
    assert "What is ML?" in content


def test_export_markdown_contains_answers(sample_history, tmp_path):
    path = str(tmp_path / "history.md")
    export_to_markdown(sample_history, output_path=path)
    with open(path) as f:
        content = f.read()
    assert "Artificial Intelligence" in content


# ─── Tests: clean_text ────────────────────────────────────────────────────────

def test_clean_text_removes_extra_newlines():
    text = "Hello\n\n\n\nWorld"
    result = clean_text(text)
    assert "\n\n\n" not in result


def test_clean_text_removes_extra_spaces():
    text = "Hello   World"
    result = clean_text(text)
    assert "  " not in result


def test_clean_text_strips_whitespace():
    text = "   Hello World   "
    result = clean_text(text)
    assert result == "Hello World"


# ─── Tests: truncate ──────────────────────────────────────────────────────────

def test_truncate_long_text():
    text = "A" * 500
    result = truncate(text, max_chars=100)
    assert result.endswith("...")
    assert len(result) == 103  # 100 + "..."


def test_truncate_short_text():
    text = "Short text"
    result = truncate(text, max_chars=100)
    assert result == "Short text"
    assert "..." not in result


def test_truncate_exact_length():
    text = "A" * 100
    result = truncate(text, max_chars=100)
    assert "..." not in result


# ─── Tests: is_supported_file ─────────────────────────────────────────────────

def test_supported_pdf():
    assert is_supported_file("document.pdf") is True


def test_supported_docx():
    assert is_supported_file("report.docx") is True


def test_supported_txt():
    assert is_supported_file("notes.txt") is True


def test_unsupported_csv():
    assert is_supported_file("data.csv") is False


def test_unsupported_xlsx():
    assert is_supported_file("sheet.xlsx") is False


def test_case_insensitive():
    assert is_supported_file("DOC.PDF") is True


# ─── Tests: get_file_size_mb ──────────────────────────────────────────────────

def test_file_size_returns_float(tmp_path):
    f = tmp_path / "test.txt"
    f.write_text("Hello World")
    size = get_file_size_mb(str(f))
    assert isinstance(size, float)
    assert size >= 0
