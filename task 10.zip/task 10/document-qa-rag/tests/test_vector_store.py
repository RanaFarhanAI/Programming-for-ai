"""
test_vector_store.py
--------------------
Unit tests for vector store similarity_search wrapper.
Uses only MagicMock — no FAISS/ChromaDB install required.
"""

import pytest
from unittest.mock import MagicMock
from langchain_core.documents import Document

# similarity_search only uses the store object's method — safe to import directly
from src.vector_store import similarity_search


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_documents():
    return [
        Document(page_content="Machine learning is a subset of AI.",    metadata={"source": "doc.txt", "chunk_index": 0}),
        Document(page_content="Deep learning uses neural networks.",     metadata={"source": "doc.txt", "chunk_index": 1}),
        Document(page_content="NLP handles text classification tasks.",  metadata={"source": "doc.txt", "chunk_index": 2}),
        Document(page_content="Computer vision processes images.",       metadata={"source": "doc.txt", "chunk_index": 3}),
    ]


@pytest.fixture
def mock_store(sample_documents):
    store = MagicMock()
    store.similarity_search_with_score.return_value = [
        (sample_documents[0], 0.95),
        (sample_documents[1], 0.82),
        (sample_documents[2], 0.71),
        (sample_documents[3], 0.60),
    ]
    return store


# ─── Tests ────────────────────────────────────────────────────────────────────

def test_similarity_search_returns_list(mock_store):
    results = similarity_search(mock_store, "What is machine learning?", top_k=4)
    assert isinstance(results, list)


def test_similarity_search_returns_tuples(mock_store):
    results = similarity_search(mock_store, "What is machine learning?", top_k=4)
    for item in results:
        assert isinstance(item, tuple)
        assert len(item) == 2


def test_similarity_search_doc_and_score(mock_store):
    results = similarity_search(mock_store, "What is machine learning?", top_k=4)
    for doc, score in results:
        assert isinstance(doc, Document)
        assert isinstance(score, float)


def test_similarity_search_calls_store_with_top_k(mock_store):
    similarity_search(mock_store, "deep learning", top_k=3)
    mock_store.similarity_search_with_score.assert_called_once_with("deep learning", k=3)


def test_similarity_search_document_has_content(mock_store):
    results = similarity_search(mock_store, "AI", top_k=4)
    for doc, _ in results:
        assert len(doc.page_content) > 0


def test_similarity_search_document_has_metadata(mock_store):
    results = similarity_search(mock_store, "AI", top_k=4)
    for doc, _ in results:
        assert "source" in doc.metadata
        assert "chunk_index" in doc.metadata


def test_similarity_search_empty_results(mock_store):
    mock_store.similarity_search_with_score.return_value = []
    results = similarity_search(mock_store, "unknown topic", top_k=4)
    assert results == []
