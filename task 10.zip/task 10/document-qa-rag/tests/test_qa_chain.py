"""
test_qa_chain.py
----------------
Unit tests for ask_question() answer parsing.
The chain itself is fully mocked — no LLM or vector store needed.
"""

import pytest
from unittest.mock import MagicMock, patch
from langchain_core.documents import Document


# Patch heavy chain imports before loading the module
with patch.dict("sys.modules", {
    "langchain.chains":  MagicMock(),
    "langchain_core.prompts": MagicMock(),
}):
    from src.qa_chain import ask_question


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def mock_chain():
    chain = MagicMock()
    chain.invoke.return_value = {
        "result": "Machine learning is a subset of AI.",
        "source_documents": [
            Document(
                page_content="Machine learning enables systems to learn from data.",
                metadata={"source": "sample.txt", "chunk_index": 0}
            ),
            Document(
                page_content="It is a branch of artificial intelligence.",
                metadata={"source": "sample.txt", "chunk_index": 1}
            ),
        ]
    }
    return chain


@pytest.fixture
def mock_chain_no_answer():
    chain = MagicMock()
    chain.invoke.return_value = {"result": "", "source_documents": []}
    return chain


@pytest.fixture
def mock_chain_long_chunk():
    chain = MagicMock()
    chain.invoke.return_value = {
        "result": "Some answer.",
        "source_documents": [
            Document(
                page_content="A" * 400,
                metadata={"source": "doc.txt", "chunk_index": 0}
            )
        ]
    }
    return chain


# ─── Tests ────────────────────────────────────────────────────────────────────

def test_ask_question_returns_dict(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    assert isinstance(result, dict)


def test_ask_question_has_answer_key(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    assert "answer" in result


def test_ask_question_has_sources_key(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    assert "sources" in result


def test_ask_question_answer_content(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    assert "machine learning" in result["answer"].lower()


def test_ask_question_sources_list(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    assert isinstance(result["sources"], list)
    assert len(result["sources"]) == 2


def test_ask_question_source_has_required_fields(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    for src in result["sources"]:
        assert "source" in src
        assert "chunk_index" in src
        assert "chunk" in src


def test_ask_question_source_filename(mock_chain):
    result = ask_question(mock_chain, "What is machine learning?")
    assert result["sources"][0]["source"] == "sample.txt"


def test_ask_question_chunk_truncated_at_300(mock_chain_long_chunk):
    result = ask_question(mock_chain_long_chunk, "question?")
    assert result["sources"][0]["chunk"].endswith("...")
    # 300 chars + "..." = 303
    assert len(result["sources"][0]["chunk"]) == 303


def test_ask_question_empty_result(mock_chain_no_answer):
    result = ask_question(mock_chain_no_answer, "What is AI?")
    assert result["answer"] == "No answer generated."
    assert result["sources"] == []


def test_ask_question_calls_chain_with_query(mock_chain):
    ask_question(mock_chain, "Test question")
    mock_chain.invoke.assert_called_once_with({"query": "Test question"})


def test_ask_question_source_chunk_index(mock_chain):
    result = ask_question(mock_chain, "What is AI?")
    assert result["sources"][0]["chunk_index"] == 0
    assert result["sources"][1]["chunk_index"] == 1
