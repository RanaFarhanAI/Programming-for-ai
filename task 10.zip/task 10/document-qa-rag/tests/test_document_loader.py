"""
test_document_loader.py
-----------------------
Unit tests for document loading and chunking.
Heavy dependencies (langchain splitter) are mocked so tests
run without requiring the full install.
"""

import os
import pytest
from unittest.mock import patch, MagicMock
from langchain_core.documents import Document


# ── Mock RecursiveCharacterTextSplitter before importing the module ────────────
class _FakeSplitter:
    def __init__(self, **kwargs):
        self.chunk_size = kwargs.get("chunk_size", 500)

    def split_text(self, text):
        # Simple fixed-size split for testing
        size = max(self.chunk_size, 10)
        return [text[i:i+size] for i in range(0, len(text), size)] or [text]


with patch.dict("sys.modules", {
    "langchain_text_splitters": MagicMock(
        RecursiveCharacterTextSplitter=_FakeSplitter
    )
}):
    from src.document_loader import (
        load_txt,
        split_into_chunks,
        load_document,
        load_and_chunk,
    )


SAMPLE_TEXT = (
    "Artificial Intelligence is transforming the world.\n"
    "Machine learning is a subset of AI.\n"
    "Deep learning uses neural networks with many layers.\n"
    "Natural language processing handles text and speech.\n"
    "Computer vision enables machines to interpret images.\n"
)


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_txt_file(tmp_path):
    f = tmp_path / "test.txt"
    f.write_text(SAMPLE_TEXT, encoding="utf-8")
    return str(f)


@pytest.fixture
def sample_docx_file(tmp_path):
    pytest.importorskip("docx", reason="python-docx not installed")
    import docx
    doc = docx.Document()
    for line in SAMPLE_TEXT.strip().split("\n"):
        if line.strip():
            doc.add_paragraph(line.strip())
    path = str(tmp_path / "test.docx")
    doc.save(path)
    return path


# ─── Tests: load_txt ──────────────────────────────────────────────────────────

def test_load_txt_returns_string(sample_txt_file):
    text = load_txt(sample_txt_file)
    assert isinstance(text, str)
    assert len(text) > 0


def test_load_txt_contains_content(sample_txt_file):
    text = load_txt(sample_txt_file)
    assert "Artificial Intelligence" in text
    assert "Machine learning" in text


# ─── Tests: load_document ─────────────────────────────────────────────────────

def test_load_document_txt(sample_txt_file):
    text = load_document(sample_txt_file)
    assert "neural networks" in text


def test_load_document_docx(sample_docx_file):
    text = load_document(sample_docx_file)
    assert len(text) > 0


def test_load_document_unsupported_raises():
    with pytest.raises(ValueError, match="Unsupported file type"):
        load_document("file.xyz")


# ─── Tests: split_into_chunks ─────────────────────────────────────────────────

def test_split_returns_documents():
    chunks = split_into_chunks(SAMPLE_TEXT, source_name="test.txt", chunk_size=100)
    assert isinstance(chunks, list)
    assert all(isinstance(c, Document) for c in chunks)


def test_split_metadata_source():
    chunks = split_into_chunks(SAMPLE_TEXT, source_name="my_doc.txt", chunk_size=100)
    for chunk in chunks:
        assert chunk.metadata["source"] == "my_doc.txt"


def test_split_metadata_chunk_index():
    chunks = split_into_chunks(SAMPLE_TEXT, source_name="test.txt", chunk_size=100)
    indices = [c.metadata["chunk_index"] for c in chunks]
    assert indices == list(range(len(chunks)))


def test_split_at_least_one_chunk():
    chunks = split_into_chunks("Hello world.", source_name="tiny.txt", chunk_size=500)
    assert len(chunks) >= 1


def test_split_content_preserved():
    chunks = split_into_chunks(SAMPLE_TEXT, source_name="test.txt", chunk_size=500)
    combined = "".join(c.page_content for c in chunks)
    assert "Artificial Intelligence" in combined


# ─── Tests: load_and_chunk ────────────────────────────────────────────────────

def test_load_and_chunk_full_pipeline(sample_txt_file):
    chunks = load_and_chunk(sample_txt_file, chunk_size=200, chunk_overlap=20)
    assert len(chunks) >= 1
    assert all(isinstance(c, Document) for c in chunks)


def test_load_and_chunk_empty_file_raises(tmp_path):
    empty = tmp_path / "empty.txt"
    empty.write_text("   ", encoding="utf-8")
    with pytest.raises(ValueError, match="No text could be extracted"):
        load_and_chunk(str(empty))


def test_load_and_chunk_source_in_metadata(sample_txt_file):
    chunks = load_and_chunk(sample_txt_file)
    for chunk in chunks:
        assert "source" in chunk.metadata
