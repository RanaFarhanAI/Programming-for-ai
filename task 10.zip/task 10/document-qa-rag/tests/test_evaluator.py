"""
test_evaluator.py
-----------------
Unit tests for answer confidence scoring and relevance checking.
"""

import pytest
from src.evaluator import score_answer_confidence, check_source_relevance


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def good_sources():
    return [
        {"source": "doc1.pdf", "chunk_index": 0, "chunk": "Machine learning is a subset of AI."},
        {"source": "doc1.pdf", "chunk_index": 1, "chunk": "Deep learning uses neural networks."},
        {"source": "doc2.pdf", "chunk_index": 0, "chunk": "NLP handles text and speech tasks."},
    ]


@pytest.fixture
def no_sources():
    return []


# ─── Tests: score_answer_confidence ──────────────────────────────────────────

def test_high_confidence_good_answer(good_sources):
    answer = "Machine learning is a subset of artificial intelligence that enables systems to learn from data."
    result = score_answer_confidence(answer, good_sources)
    assert result["score"] >= 80
    assert result["label"] == "High"


def test_low_confidence_short_answer(good_sources):
    answer = "Yes."
    result = score_answer_confidence(answer, good_sources)
    assert result["score"] < 80


def test_low_confidence_uncertainty_phrase(good_sources):
    answer = "I don't have enough information to answer that question."
    result = score_answer_confidence(answer, good_sources)
    # Uncertainty phrase must be flagged regardless of final score
    assert any("Uncertainty" in f for f in result["flags"])


def test_low_confidence_no_sources():
    answer = "Machine learning is a powerful technique used in AI applications."
    result = score_answer_confidence(answer, [])
    # No sources → penalised, score should be below a perfect 100
    assert result["score"] < 100
    assert any("No source" in f for f in result["flags"])


def test_confidence_score_clamped(good_sources):
    answer = "This is a very detailed and comprehensive answer about machine learning."
    result = score_answer_confidence(answer, good_sources)
    assert 0 <= result["score"] <= 100


def test_confidence_returns_required_keys(good_sources):
    result = score_answer_confidence("Some answer.", good_sources)
    assert "score" in result
    assert "label" in result
    assert "flags" in result


def test_confidence_label_values(good_sources):
    result = score_answer_confidence("Some answer.", good_sources)
    assert result["label"] in ("High", "Medium", "Low")


# ─── Tests: check_source_relevance ───────────────────────────────────────────

def test_relevance_returns_list(good_sources):
    result = check_source_relevance("What is machine learning?", good_sources)
    assert isinstance(result, list)
    assert len(result) == len(good_sources)


def test_relevance_adds_relevance_pct(good_sources):
    result = check_source_relevance("What is machine learning?", good_sources)
    for src in result:
        assert "relevance_pct" in src
        assert 0 <= src["relevance_pct"] <= 100


def test_relevance_sorted_descending(good_sources):
    result = check_source_relevance("machine learning neural networks", good_sources)
    scores = [r["relevance_pct"] for r in result]
    assert scores == sorted(scores, reverse=True)


def test_relevance_keyword_match(good_sources):
    result = check_source_relevance("machine learning", good_sources)
    # The chunk mentioning "machine learning" should score higher
    top = result[0]
    assert top["relevance_pct"] > 0


def test_relevance_empty_sources():
    result = check_source_relevance("What is AI?", [])
    assert result == []


def test_relevance_adds_keyword_matches(good_sources):
    result = check_source_relevance("deep learning neural", good_sources)
    for src in result:
        assert "keyword_matches" in src
