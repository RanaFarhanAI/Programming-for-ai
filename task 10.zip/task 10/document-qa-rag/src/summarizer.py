"""
summarizer.py
-------------
Document summarization using langchain_core only.
Works with LangChain 1.x — no deprecated load_summarize_chain needed.
"""

from typing import List
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate


def _call_llm(llm, prompt_text: str) -> str:
    """Call LLM and extract string response."""
    response = llm.invoke(prompt_text)
    if hasattr(response, "content"):
        return response.content.strip()
    return str(response).strip()


def _chunk_text(docs: List[Document], max_docs: int = 10) -> str:
    """Concatenate document chunks into a single context string."""
    return "\n\n".join(doc.page_content for doc in docs[:max_docs])


def summarize_short(documents: List[Document], llm) -> str:
    """One-paragraph summary."""
    context = _chunk_text(documents, max_docs=10)
    prompt = f"""Write a concise one-paragraph summary of the following text.
Focus on the main topic, key points, and conclusions.

Text:
{context}

Summary:"""
    return _call_llm(llm, prompt) or "Could not generate summary."


def summarize_detailed(documents: List[Document], llm) -> str:
    """Bullet-point summary. Uses map-reduce for long documents."""
    if len(documents) <= 8:
        context = _chunk_text(documents)
        prompt = f"""Summarize the following text as a bullet-point list.
Include the main topic, key facts, and important conclusions.

Text:
{context}

Bullet Points:"""
        return _call_llm(llm, prompt) or "Could not generate summary."
    else:
        # Map: summarize each chunk
        chunk_summaries = []
        for doc in documents:
            p = f"Summarize the key points from this section:\n\n{doc.page_content}\n\nKey Points:"
            chunk_summaries.append(_call_llm(llm, p))

        # Reduce: combine summaries
        combined = "\n\n".join(chunk_summaries)
        reduce_prompt = f"""Combine these section summaries into one coherent bullet-point summary.

Summaries:
{combined}

Final Summary:"""
        return _call_llm(llm, reduce_prompt) or "Could not generate summary."


def extract_key_topics(documents: List[Document], llm) -> str:
    """Numbered list of main topics."""
    context = _chunk_text(documents, max_docs=8)
    prompt = f"""List the main topics and themes covered in this text as a numbered list.

Text:
{context}

Main Topics:"""
    return _call_llm(llm, prompt) or "Could not extract topics."


def get_document_stats(documents: List[Document]) -> dict:
    total_chars = sum(len(doc.page_content) for doc in documents)
    avg_chunk   = total_chars // len(documents) if documents else 0
    sources     = list({doc.metadata.get("source", "unknown") for doc in documents})
    return {
        "total_chunks":     len(documents),
        "total_characters": total_chars,
        "avg_chunk_size":   avg_chunk,
        "estimated_words":  total_chars // 5,
        "sources":          sources,
    }
