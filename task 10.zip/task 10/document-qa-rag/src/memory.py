"""
memory.py
---------
Conversational Q&A with memory — built with langchain_core only.
Keeps a rolling window of past Q&A pairs as context.
Works with LangChain 1.x.
"""

from typing import List, Dict, Any
from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document


CONV_PROMPT = PromptTemplate(
    input_variables=["chat_history", "context", "question"],
    template="""You are a helpful assistant. Use ONLY the context below to answer.
If the answer is not in the context, say "I don't have enough information to answer that."
Use the chat history to understand follow-up questions.

Chat History:
{chat_history}

Context:
{context}

Question: {question}

Answer:"""
)


def build_conversational_chain(vector_store, llm, top_k: int = 4, memory_window: int = 5):
    """
    Returns a stateful chain dict.
    Memory is stored in the dict itself — no external memory class needed.
    """
    retriever = vector_store.as_retriever(
        search_type="similarity",
        search_kwargs={"k": top_k}
    )
    print(f"[Memory] Conversational chain built (window={memory_window}, top_k={top_k})")
    return {
        "retriever":     retriever,
        "llm":           llm,
        "prompt":        CONV_PROMPT,
        "history":       [],          # list of {"question": ..., "answer": ...}
        "memory_window": memory_window,
    }


def ask_with_memory(chain: dict, question: str) -> Dict[str, Any]:
    """Ask a question, using rolling chat history as extra context."""
    retriever     = chain["retriever"]
    llm           = chain["llm"]
    prompt        = chain["prompt"]
    history       = chain["history"]
    memory_window = chain["memory_window"]

    # 1. Retrieve docs
    docs = retriever.invoke(question)
    context = "\n\n".join(doc.page_content for doc in docs)

    # 2. Build chat history string (last N turns)
    recent = history[-memory_window:]
    history_str = "\n".join(
        f"Human: {h['question']}\nAssistant: {h['answer']}"
        for h in recent
    ) if recent else "None"

    # 3. Format prompt
    prompt_text = prompt.format(
        chat_history=history_str,
        context=context,
        question=question
    )

    # 4. Call LLM
    response = llm.invoke(prompt_text)
    answer = response.content if hasattr(response, "content") else str(response)
    answer = answer.strip() or "No answer generated."

    # 5. Save to history
    chain["history"].append({"question": question, "answer": answer})

    # 6. Build sources
    sources = []
    for doc in docs:
        sources.append({
            "source":      doc.metadata.get("source", "unknown"),
            "chunk_index": doc.metadata.get("chunk_index", "?"),
            "chunk":       doc.page_content[:300] + "..." if len(doc.page_content) > 300 else doc.page_content
        })

    return {"answer": answer, "sources": sources}


def get_chat_history(chain: dict) -> List[Dict[str, str]]:
    return chain.get("history", [])


def clear_memory(chain: dict):
    chain["history"] = []
    print("[Memory] Conversation history cleared.")
