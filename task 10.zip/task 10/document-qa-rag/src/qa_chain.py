"""
qa_chain.py
-----------
RAG chain built with langchain_core LCEL (LangChain Expression Language).
Works with LangChain 1.x — no deprecated RetrievalQA needed.
"""

from typing import Dict, Any, List
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_core.documents import Document


RAG_PROMPT = PromptTemplate(
    input_variables=["context", "question"],
    template="""You are a helpful assistant. Use ONLY the context below to answer the question.
If the answer is not in the context, say "I don't have enough information to answer that."

Context:
{context}

Question: {question}

Answer:"""
)


def _format_docs(docs: List[Document]) -> str:
    return "\n\n".join(doc.page_content for doc in docs)


def build_qa_chain(vector_store, llm, top_k: int = 4):
    """
    Build a RAG chain using LCEL.
    Returns a dict with 'chain' and 'retriever' so we can access source docs.
    """
    retriever = vector_store.as_retriever(
        search_type="similarity",
        search_kwargs={"k": top_k}
    )
    print(f"[QA Chain] Built with top_k={top_k} retrieval.")
    # Return a simple object that ask_question() knows how to call
    return {"retriever": retriever, "llm": llm, "prompt": RAG_PROMPT}


def ask_question(chain: dict, question: str) -> Dict[str, Any]:
    """
    Run a question through the RAG chain.
    chain is the dict returned by build_qa_chain().
    """
    retriever = chain["retriever"]
    llm       = chain["llm"]
    prompt    = chain["prompt"]

    # 1. Retrieve relevant docs
    docs = retriever.invoke(question)

    # 2. Build context string
    context = _format_docs(docs)

    # 3. Format prompt
    prompt_text = prompt.format(context=context, question=question)

    # 4. Call LLM
    response = llm.invoke(prompt_text)

    # Handle string response (our wrapper), message object (OpenAI), or plain string
    if hasattr(response, "content"):
        answer = response.content
    else:
        answer = str(response)

    answer = answer.strip() or "No answer generated."

    # 5. Build source list
    sources = []
    for doc in docs:
        sources.append({
            "source":      doc.metadata.get("source", "unknown"),
            "chunk_index": doc.metadata.get("chunk_index", "?"),
            "chunk":       doc.page_content[:300] + "..." if len(doc.page_content) > 300 else doc.page_content
        })

    return {"answer": answer, "sources": sources}
