"""
llm_provider.py
---------------
Works with transformers 4.x (stable).
Uses text2text-generation pipeline for FLAN-T5.
"""

import os
from dotenv import load_dotenv

load_dotenv()


def get_llm(provider: str = "huggingface"):
    if provider == "openai":
        return _get_openai_llm()
    elif provider == "huggingface":
        return _get_huggingface_llm()
    else:
        raise ValueError(f"Unknown provider: {provider}. Use 'openai' or 'huggingface'.")


def _get_openai_llm():
    try:
        from langchain_openai import ChatOpenAI
    except ImportError:
        raise ImportError("Run: pip install langchain-openai")
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set in .env file.")
    print("[LLM] Using OpenAI GPT-3.5-turbo")
    return ChatOpenAI(model="gpt-3.5-turbo", temperature=0.2, api_key=api_key)


def _get_huggingface_llm():
    """
    FLAN-T5 via direct model call — works with transformers 4.x and 5.x.
    No pipeline() used — avoids all version compatibility issues.
    """
    import torch
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

    model_name = os.getenv("HF_MODEL_NAME", "google/flan-t5-base")
    print(f"[LLM] Loading HuggingFace model: {model_name}")

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model     = AutoModelForSeq2SeqLM.from_pretrained(model_name)
    model.eval()

    print(f"[LLM] Model loaded successfully.")
    return _DirectSeq2SeqLLM(model, tokenizer)


class _DirectSeq2SeqLLM:
    """
    Direct seq2seq wrapper — no pipeline(), works with any transformers version.
    """

    def __init__(self, model, tokenizer):
        self._model     = model
        self._tokenizer = tokenizer

    def invoke(self, prompt: str, **kwargs) -> str:
        import torch

        inputs = self._tokenizer(
            str(prompt),
            return_tensors="pt",
            max_length=512,
            truncation=True,
        )

        with torch.no_grad():
            output_ids = self._model.generate(
                **inputs,
                max_new_tokens=256,
                do_sample=False,
                num_beams=2,
            )

        answer = self._tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return answer.strip() or "No answer generated."

    def __call__(self, prompt: str, **kwargs) -> str:
        return self.invoke(prompt)

    @property
    def _llm_type(self) -> str:
        return "flan-t5-direct"
