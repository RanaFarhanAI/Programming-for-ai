"""
config.py
---------
Central configuration loaded from environment variables (.env).
Import this anywhere instead of calling os.getenv() directly.
"""

import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    # ── LLM ───────────────────────────────────────────────────────────────────
    llm_provider: str      = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "huggingface"))
    openai_api_key: str    = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    hf_token: str          = field(default_factory=lambda: os.getenv("HUGGINGFACE_API_TOKEN", ""))
    hf_model_name: str     = field(default_factory=lambda: os.getenv("HF_MODEL_NAME", "google/flan-t5-base"))

    # ── Embeddings ────────────────────────────────────────────────────────────
    embedding_model: str   = field(default_factory=lambda: os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2"))

    # ── Vector Store ──────────────────────────────────────────────────────────
    vector_store: str      = field(default_factory=lambda: os.getenv("VECTOR_STORE", "faiss"))
    faiss_index_path: str  = field(default_factory=lambda: os.getenv("FAISS_INDEX_PATH", "faiss_index"))
    chroma_db_path: str    = field(default_factory=lambda: os.getenv("CHROMA_DB_PATH", "chroma_db"))

    # ── Chunking ──────────────────────────────────────────────────────────────
    chunk_size: int        = field(default_factory=lambda: int(os.getenv("CHUNK_SIZE", "500")))
    chunk_overlap: int     = field(default_factory=lambda: int(os.getenv("CHUNK_OVERLAP", "50")))

    # ── Retrieval ─────────────────────────────────────────────────────────────
    top_k: int             = field(default_factory=lambda: int(os.getenv("TOP_K", "4")))
    memory_window: int     = field(default_factory=lambda: int(os.getenv("MEMORY_WINDOW", "5")))

    def validate(self):
        """Raise clear errors for missing required config."""
        if self.llm_provider == "openai" and not self.openai_api_key:
            raise ValueError(
                "OPENAI_API_KEY is not set in .env. "
                "Either add it or switch LLM_PROVIDER=huggingface."
            )
        if self.vector_store not in ("faiss", "chroma"):
            raise ValueError(f"VECTOR_STORE must be 'faiss' or 'chroma', got: {self.vector_store}")
        if self.llm_provider not in ("openai", "huggingface"):
            raise ValueError(f"LLM_PROVIDER must be 'openai' or 'huggingface', got: {self.llm_provider}")

    def summary(self) -> str:
        return (
            f"Config:\n"
            f"  LLM Provider   : {self.llm_provider}\n"
            f"  HF Model       : {self.hf_model_name}\n"
            f"  Embedding Model: {self.embedding_model}\n"
            f"  Vector Store   : {self.vector_store}\n"
            f"  Chunk Size     : {self.chunk_size}\n"
            f"  Chunk Overlap  : {self.chunk_overlap}\n"
            f"  Top-K          : {self.top_k}\n"
            f"  Memory Window  : {self.memory_window}\n"
        )


# Singleton — import this everywhere
cfg = Config()
