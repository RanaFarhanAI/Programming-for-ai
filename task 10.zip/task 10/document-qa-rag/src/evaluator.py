"""
evaluator.py
------------
Evaluates the quality of RAG answers.
Provides confidence scoring, relevance checks, and a simple
benchmark runner for testing the system against known Q&A pairs.
"""

from typing import List, Dict, Tuple
from langchain_core.documents import Document
import re


# ─── Confidence Scoring ───────────────────────────────────────────────────────

def score_answer_confidence(answer: str, sources: List[Dict]) -> Dict:
    """
    Heuristic confidence scoring based on:
    - Answer length (too short = low confidence)
    - Presence of uncertainty phrases
    - Number of source chunks retrieved
    - Source diversity (multiple files = higher confidence)
    """
    score = 100
    flags = []

    # Penalize very short answers
    if len(answer.strip()) < 20:
        score -= 40
        flags.append("Answer is very short")

    # Penalize uncertainty phrases
    uncertainty_phrases = [
        "i don't know", "i don't have", "not enough information",
        "cannot answer", "unclear", "not mentioned", "no information"
    ]
    answer_lower = answer.lower()
    for phrase in uncertainty_phrases:
        if phrase in answer_lower:
            score -= 30
            flags.append(f"Uncertainty detected: '{phrase}'")
            break

    # Reward more source chunks
    if len(sources) >= 3:
        score += 10
    elif len(sources) == 0:
        score -= 20
        flags.append("No source chunks retrieved")

    # Reward source diversity
    unique_sources = {s.get("source", "") for s in sources}
    if len(unique_sources) > 1:
        score += 5

    score = max(0, min(100, score))  # clamp to [0, 100]

    return {
        "score": score,
        "label": _score_label(score),
        "flags": flags
    }


def _score_label(score: int) -> str:
    if score >= 80:
        return "High"
    elif score >= 50:
        return "Medium"
    else:
        return "Low"


# ─── Relevance Check ──────────────────────────────────────────────────────────

def check_source_relevance(question: str, sources: List[Dict]) -> List[Dict]:
    """
    Simple keyword-based relevance check.
    Checks how many question keywords appear in each retrieved chunk.
    """
    # Extract meaningful keywords (ignore stopwords)
    stopwords = {"what", "is", "are", "the", "a", "an", "of", "in", "on",
                 "how", "why", "when", "where", "who", "does", "do", "was",
                 "were", "has", "have", "can", "could", "would", "should"}

    keywords = [
        w.lower().strip("?.!,")
        for w in question.split()
        if w.lower() not in stopwords and len(w) > 2
    ]

    scored_sources = []
    for src in sources:
        chunk_lower = src["chunk"].lower()
        matches = sum(1 for kw in keywords if kw in chunk_lower)
        relevance = round(matches / len(keywords) * 100) if keywords else 0
        scored_sources.append({**src, "relevance_pct": relevance, "keyword_matches": matches})

    # Sort by relevance descending
    scored_sources.sort(key=lambda x: x["relevance_pct"], reverse=True)
    return scored_sources


# ─── Benchmark Runner ─────────────────────────────────────────────────────────

# Sample benchmark Q&A pairs for the included sample.txt
SAMPLE_BENCHMARKS = [
    {
        "question": "What is machine learning?",
        "expected_keywords": ["learn", "data", "experience", "programmed"]
    },
    {
        "question": "What are the types of machine learning?",
        "expected_keywords": ["supervised", "unsupervised", "reinforcement"]
    },
    {
        "question": "What is deep learning used for?",
        "expected_keywords": ["neural", "vision", "language", "speech"]
    },
    {
        "question": "What are the challenges in AI?",
        "expected_keywords": ["bias", "privacy", "ethical", "cost"]
    },
    {
        "question": "What is NLP?",
        "expected_keywords": ["language", "text", "translation", "classification"]
    }
]


def run_benchmark(chain, benchmarks: List[Dict] = None) -> List[Dict]:
    """
    Run a set of benchmark questions and evaluate answers.
    Returns a list of results with scores.
    """
    from src.qa_chain import ask_question

    if benchmarks is None:
        benchmarks = SAMPLE_BENCHMARKS

    results = []
    print(f"\n[Benchmark] Running {len(benchmarks)} test questions...\n")

    for i, item in enumerate(benchmarks):
        question = item["question"]
        expected_keywords = item.get("expected_keywords", [])

        result = ask_question(chain, question)
        answer = result["answer"]
        sources = result["sources"]

        # Check how many expected keywords appear in the answer
        answer_lower = answer.lower()
        keyword_hits = [kw for kw in expected_keywords if kw in answer_lower]
        keyword_score = round(len(keyword_hits) / len(expected_keywords) * 100) if expected_keywords else 0

        confidence = score_answer_confidence(answer, sources)

        results.append({
            "question": question,
            "answer": answer,
            "expected_keywords": expected_keywords,
            "keyword_hits": keyword_hits,
            "keyword_score": keyword_score,
            "confidence": confidence,
            "sources_count": len(sources)
        })

        print(f"  Q{i+1}: {question}")
        print(f"  A: {answer[:100]}...")
        print(f"  Keyword Score: {keyword_score}% | Confidence: {confidence['label']}\n")

    avg_keyword_score = sum(r["keyword_score"] for r in results) / len(results)
    avg_confidence = sum(r["confidence"]["score"] for r in results) / len(results)

    print(f"[Benchmark] Avg Keyword Score: {avg_keyword_score:.1f}%")
    print(f"[Benchmark] Avg Confidence:    {avg_confidence:.1f}/100")

    return results
