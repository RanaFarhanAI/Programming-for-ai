"""
vector_store.py
---------------
Manages embedding generation and vector store operations.
Supports both FAISS (local file-based) and ChromaDB (persistent DB).
"""

import os
from typing import List, Tuple
from langchain_core.documents import Document


FAISS_INDEX_PATH = "faiss_index"
CHROMA_DB_PATH   = "chroma_db"


def get_embeddings(model_name: str = "all-MiniLM-L6-v2"):
    """
    Load a sentence-transformer embedding model.
    Runs locally — no API key required.
    'all-MiniLM-L6-v2' is fast and accurate for most use cases.
    """
    from langchain_huggingface import HuggingFaceEmbeddings
    print(f"[Embeddings] Loading model: {model_name}")
    return HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True}
    )


# ─── FAISS ────────────────────────────────────────────────────────────────────

def build_faiss_index(documents: List[Document], embeddings) -> "FAISS":
    """Create a new FAISS index from documents and save it to disk."""
    from langchain_community.vectorstores import FAISS
    print(f"[FAISS] Building index from {len(documents)} chunks...")
    db = FAISS.from_documents(documents, embeddings)
    db.save_local(FAISS_INDEX_PATH)
    print(f"[FAISS] Index saved to '{FAISS_INDEX_PATH}'")
    return db


def load_faiss_index(embeddings) -> "FAISS":
    """Load an existing FAISS index from disk."""
    from langchain_community.vectorstores import FAISS
    if not os.path.exists(FAISS_INDEX_PATH):
        raise FileNotFoundError(
            f"FAISS index not found at '{FAISS_INDEX_PATH}'. "
            "Please upload and index a document first."
        )
    print(f"[FAISS] Loading index from '{FAISS_INDEX_PATH}'")
    return FAISS.load_local(
        FAISS_INDEX_PATH,
        embeddings,
        allow_dangerous_deserialization=True
    )


def add_to_faiss_index(new_docs: List[Document], embeddings) -> "FAISS":
    """Add new documents to an existing FAISS index (or create one)."""
    if os.path.exists(FAISS_INDEX_PATH):
        db = load_faiss_index(embeddings)
        db.add_documents(new_docs)
        db.save_local(FAISS_INDEX_PATH)
        print(f"[FAISS] Added {len(new_docs)} chunks to existing index.")
    else:
        db = build_faiss_index(new_docs, embeddings)
    return db


# ─── ChromaDB ─────────────────────────────────────────────────────────────────

def build_chroma_index(documents: List[Document], embeddings) -> "Chroma":
    """Create or update a ChromaDB collection from documents."""
    from langchain_community.vectorstores import Chroma
    print(f"[Chroma] Building collection from {len(documents)} chunks...")
    db = Chroma.from_documents(documents, embeddings, persist_directory=CHROMA_DB_PATH)
    print(f"[Chroma] Collection saved to '{CHROMA_DB_PATH}'")
    return db


def load_chroma_index(embeddings) -> "Chroma":
    """Load an existing ChromaDB collection."""
    from langchain_community.vectorstores import Chroma
    if not os.path.exists(CHROMA_DB_PATH):
        raise FileNotFoundError(
            f"ChromaDB not found at '{CHROMA_DB_PATH}'. "
            "Please upload and index a document first."
        )
    print(f"[Chroma] Loading collection from '{CHROMA_DB_PATH}'")
    return Chroma(persist_directory=CHROMA_DB_PATH, embedding_function=embeddings)


# ─── Unified API ──────────────────────────────────────────────────────────────

def get_or_build_store(documents: List[Document], embeddings, store_type: str = "faiss"):
    """Build or update a vector store based on store_type ('faiss' or 'chroma')."""
    if store_type == "faiss":
        return add_to_faiss_index(documents, embeddings)
    elif store_type == "chroma":
        return build_chroma_index(documents, embeddings)
    else:
        raise ValueError(f"Unknown store type: {store_type}. Use 'faiss' or 'chroma'.")


def load_store(embeddings, store_type: str = "faiss"):
    """Load an existing vector store."""
    if store_type == "faiss":
        return load_faiss_index(embeddings)
    elif store_type == "chroma":
        return load_chroma_index(embeddings)
    else:
        raise ValueError(f"Unknown store type: {store_type}.")


def similarity_search(
    store,
    query: str,
    top_k: int = 4
) -> List[Tuple[Document, float]]:
    """Return top-k most relevant chunks with their similarity scores."""
    return store.similarity_search_with_score(query, k=top_k)
