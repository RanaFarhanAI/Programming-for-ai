"""
utils.py
--------
Shared utility functions used across the project.
"""

import os
import json
import time
from datetime import datetime
from typing import List, Dict


# ─── Export ───────────────────────────────────────────────────────────────────

def export_chat_history(history: List[Dict], output_path: str = None) -> str:
    """
    Export Q&A history to a JSON file.
    Returns the path of the saved file.
    """
    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = f"qa_history_{timestamp}.json"

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)

    print(f"[Export] Chat history saved to '{output_path}'")
    return output_path


def export_to_markdown(history: List[Dict], output_path: str = None) -> str:
    """Export Q&A history to a readable Markdown file."""
    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = f"qa_history_{timestamp}.md"

    lines = [f"# Document Q&A Session\n", f"*Exported: {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n\n---\n"]

    for i, item in enumerate(history, 1):
        lines.append(f"## Q{i}: {item['question']}\n")
        lines.append(f"**Answer:** {item['answer']}\n\n")

        if item.get("sources"):
            lines.append("**Sources:**\n")
            for src in item["sources"]:
                lines.append(f"- `{src['source']}` — Chunk #{src.get('chunk_index', '?')}\n")
        lines.append("\n---\n")

    with open(output_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    print(f"[Export] Markdown saved to '{output_path}'")
    return output_path


# ─── Timing ───────────────────────────────────────────────────────────────────

class Timer:
    """Simple context manager for timing operations."""

    def __init__(self, label: str = "Operation"):
        self.label = label
        self.elapsed = 0.0

    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        self.elapsed = time.time() - self.start
        print(f"[Timer] {self.label}: {self.elapsed:.2f}s")


# ─── File Helpers ─────────────────────────────────────────────────────────────

def get_file_size_mb(path: str) -> float:
    """Return file size in MB."""
    return os.path.getsize(path) / (1024 * 1024)


def is_supported_file(filename: str) -> bool:
    """Check if a file extension is supported."""
    return os.path.splitext(filename)[1].lower() in {".pdf", ".docx", ".txt"}


def clean_text(text: str) -> str:
    """Remove excessive whitespace and normalize line endings."""
    import re
    text = re.sub(r'\n{3,}', '\n\n', text)   # max 2 consecutive newlines
    text = re.sub(r' {2,}', ' ', text)         # collapse multiple spaces
    return text.strip()


def truncate(text: str, max_chars: int = 300) -> str:
    """Truncate text with ellipsis."""
    return text[:max_chars] + "..." if len(text) > max_chars else text


# ─── Index Management ─────────────────────────────────────────────────────────

def clear_vector_store(store_type: str = "faiss"):
    """Delete the saved vector store from disk."""
    import shutil

    paths = {
        "faiss": "faiss_index",
        "chroma": "chroma_db"
    }

    path = paths.get(store_type)
    if path and os.path.exists(path):
        shutil.rmtree(path)
        print(f"[Utils] Cleared {store_type} index at '{path}'")
    else:
        print(f"[Utils] No {store_type} index found to clear.")


def list_indexed_sources(store_type: str = "faiss") -> List[str]:
    """
    Try to list source filenames from the vector store metadata.
    Returns empty list if store doesn't exist.
    """
    paths = {"faiss": "faiss_index", "chroma": "chroma_db"}
    path = paths.get(store_type, "")

    if not os.path.exists(path):
        return []

    # Read docstore for FAISS
    if store_type == "faiss":
        pkl_path = os.path.join(path, "index.pkl")
        if os.path.exists(pkl_path):
            import pickle
            with open(pkl_path, "rb") as f:
                data = pickle.load(f)
            sources = set()
            for doc in data[1].values():
                src = doc.metadata.get("source", "")
                if src:
                    sources.add(src)
            return sorted(sources)

    return []
