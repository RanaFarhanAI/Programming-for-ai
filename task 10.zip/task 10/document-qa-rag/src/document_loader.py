"""
document_loader.py
------------------
Handles loading and parsing of PDF and DOCX files into plain text chunks.
All heavy dependencies (PyPDF2, docx, splitter) are imported lazily
so the module loads even when optional packages are not installed.
"""

import os
from typing import List
from langchain_core.documents import Document


def load_pdf(file_path: str) -> str:
    """Extract all text from a PDF file."""
    import PyPDF2
    text = ""
    with open(file_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            extracted = page.extract_text()
            if extracted:
                text += extracted + "\n"
    return text


def load_docx(file_path: str) -> str:
    """Extract all text from a DOCX file."""
    import docx
    doc = docx.Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs if para.text.strip()])


def load_txt(file_path: str) -> str:
    """Read plain text file."""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def load_document(file_path: str) -> str:
    """
    Auto-detect file type and load content.
    Supports: .pdf, .docx, .txt
    """
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return load_pdf(file_path)
    elif ext == ".docx":
        return load_docx(file_path)
    elif ext == ".txt":
        return load_txt(file_path)
    else:
        raise ValueError(f"Unsupported file type: {ext}. Supported: .pdf, .docx, .txt")


def split_into_chunks(
    text: str,
    source_name: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50
) -> List[Document]:
    """
    Split raw text into overlapping chunks for better retrieval.
    Each chunk is wrapped in a LangChain Document with metadata.
    """
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separators=["\n\n", "\n", ".", " ", ""]
        )
        raw_chunks = splitter.split_text(text)
    except ImportError:
        # Built-in fallback: simple fixed-size chunking with overlap
        raw_chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            raw_chunks.append(text[start:end])
            start += chunk_size - chunk_overlap
            if start >= len(text):
                break

    documents = [
        Document(
            page_content=chunk,
            metadata={"source": source_name, "chunk_index": i}
        )
        for i, chunk in enumerate(raw_chunks)
    ]

    print(f"[Loader] '{source_name}' → {len(documents)} chunks created.")
    return documents


def load_and_chunk(
    file_path: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50
) -> List[Document]:
    """Full pipeline: load file → extract text → split into chunks."""
    source_name = os.path.basename(file_path)
    text = load_document(file_path)

    if not text.strip():
        raise ValueError(f"No text could be extracted from '{file_path}'.")

    return split_into_chunks(text, source_name, chunk_size, chunk_overlap)
