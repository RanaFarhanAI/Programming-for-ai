# 📄 Document Q&A System (RAG)

A full Retrieval-Augmented Generation (RAG) system — upload PDF, DOCX, or TXT files and ask natural language questions about their content.

---

## 🏗️ Architecture

```
User Question
     │
     ▼
[Embedding Model]        ← sentence-transformers (all-MiniLM-L6-v2)
     │
     ▼
[Vector Store]           ← FAISS (fast) or ChromaDB (persistent)
  similarity search → top-k relevant chunks
     │
     ▼
[LLM]                    ← HuggingFace FLAN-T5 (free) or OpenAI GPT-3.5
  context + question → grounded answer
     │
     ▼
Answer + Confidence Score + Source References
```

---

## 📁 Project Structure

```
document-qa-rag/
├── app.py                      # Streamlit web UI (5 tabs)
├── cli.py                      # Command-line interface
├── Makefile                    # Shortcut commands
├── requirements.txt
├── .env.example                # Config template
│
├── sample_data/
│   ├── sample.txt              # AI/ML overview document
│   └── legal_sample.txt        # Software license agreement
│
├── src/
│   ├── config.py               # Central config (reads .env)
│   ├── document_loader.py      # PDF/DOCX/TXT loading & chunking
│   ├── vector_store.py         # FAISS & ChromaDB management
│   ├── llm_provider.py         # OpenAI & HuggingFace LLMs
│   ├── qa_chain.py             # Single-turn RAG chain
│   ├── memory.py               # Conversational chain with memory
│   ├── summarizer.py           # Document summarization
│   ├── evaluator.py            # Confidence scoring & benchmarks
│   └── utils.py                # Export, timing, helpers
│
└── tests/
    ├── test_document_loader.py
    ├── test_evaluator.py
    ├── test_qa_chain.py
    ├── test_utils.py
    └── test_vector_store.py
```

---

## 🚀 Quick Start

### 1. Install
```bash
pip install -r requirements.txt
```

### 2. Configure
```bash
cp .env.example .env
# Default config works out of the box (free HuggingFace models)
```

### 3. Run the Web App (Frontend + API)
```bash
# Start the FastAPI backend — frontend is served automatically at http://localhost:8000
uvicorn api:app --reload

# or
make serve
```

Open **http://localhost:8000** in your browser.

### 4. Run the legacy Streamlit UI (optional)
```bash
streamlit run app.py
```

### 5. Run the CLI
```bash
python cli.py --file sample_data/sample.txt
make cli
```

---

## 🖥️ Web UI Features (5 Tabs)

| Tab | Feature |
|---|---|
| 📥 Upload | Upload files, index chunks, view stats |
| 💬 Q&A | Ask questions, view answers with confidence scores |
| 📋 Summarize | Short / detailed / key topics summary |
| 📊 Evaluate | Run benchmark, view keyword & confidence scores |
| 💾 Export | Download chat history as JSON or Markdown |

---

## ⚙️ Configuration (`.env`)

| Variable | Default | Description |
|---|---|---|
| `LLM_PROVIDER` | `huggingface` | `huggingface` or `openai` |
| `HF_MODEL_NAME` | `google/flan-t5-base` | HuggingFace model |
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | Sentence transformer |
| `VECTOR_STORE` | `faiss` | `faiss` or `chroma` |
| `CHUNK_SIZE` | `500` | Characters per chunk |
| `CHUNK_OVERLAP` | `50` | Overlap between chunks |
| `TOP_K` | `4` | Chunks retrieved per query |
| `MEMORY_WINDOW` | `5` | Past Q&A pairs kept in memory |
| `OPENAI_API_KEY` | _(empty)_ | Required only for OpenAI |

---

## 🆓 Free Setup (No API Key)

Default config uses models that run fully locally:
- **Embeddings**: `all-MiniLM-L6-v2` (~90MB)
- **LLM**: `google/flan-t5-base` (~250MB)

First run downloads models automatically. No API key needed.

> For better answers, switch to `google/flan-t5-large` or `google/flan-t5-xl` in `.env`.

---

## 💰 OpenAI Setup

```env
OPENAI_API_KEY=sk-...
LLM_PROVIDER=openai
```

Uses `gpt-3.5-turbo` — much better answers, costs ~$0.002 per query.

---

## 🧪 Run Tests

```bash
# All tests
pytest tests/ -v

# With coverage
pytest tests/ --cov=src --cov-report=term-missing

# or
make test
```

---

## 📦 Supported File Types

| Format | Library |
|---|---|
| `.pdf` | PyPDF2 |
| `.docx` | python-docx |
| `.txt` | built-in |

---

## 💡 Example Questions

**For `sample.txt` (AI/ML):**
- "What is the difference between supervised and unsupervised learning?"
- "What are the applications of AI in healthcare?"
- "What challenges does AI face?"

**For `legal_sample.txt` (License):**
- "Can I redistribute this software?"
- "What happens if I breach the agreement?"
- "Which state's law governs this agreement?"
- "Is warranty included?"
