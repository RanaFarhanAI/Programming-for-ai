"""
api.py
------
FastAPI backend for the DocuMind frontend.
"""

import os
import traceback
import tempfile

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from src.document_loader import load_and_chunk
from src.vector_store import get_embeddings, get_or_build_store
from src.llm_provider import get_llm
from src.qa_chain import build_qa_chain, ask_question
from src.memory import build_conversational_chain, ask_with_memory, clear_memory
from src.summarizer import summarize_short, summarize_detailed, extract_key_topics, get_document_stats
from src.evaluator import run_benchmark, score_answer_confidence, check_source_relevance

app = FastAPI(title="DocuMind API", version="1.0.0")

# ── CORS ───────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global error handler — always return JSON, never plain text ────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    tb = traceback.format_exc()
    print(f"\n[ERROR] {exc}\n{tb}")          # visible in your terminal
    return JSONResponse(
        status_code=500,
        content={"detail": str(exc), "traceback": tb},
    )

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail},
    )

# ── App state ──────────────────────────────────────────────────────────────
_state = {
    "indexed":      False,
    "all_chunks":   [],
    "vector_store": None,
    "llm":          None,
    "embeddings":   None,
    "qa_chain":     None,
    "conv_chain":   None,
    "stats":        {},
}

# ── Models ─────────────────────────────────────────────────────────────────
class AskRequest(BaseModel):
    question: str
    mode: str = "single"
    top_k: int = 4

class SummarizeRequest(BaseModel):
    summary_type: str = "short"


# ── Endpoints ──────────────────────────────────────────────────────────────

@app.get("/api/status")
def status():
    return {
        "indexed": _state["indexed"],
        "sources": _state["stats"].get("sources", []),
    }


@app.post("/api/index")
async def index_documents(
    files: list[UploadFile] = File(...),
    llm_provider: str  = Form("huggingface"),
    vector_store: str  = Form("faiss"),
    chunk_size: int    = Form(500),
    chunk_overlap: int = Form(50),
    top_k: int         = Form(4),
):
    if not files:
        raise HTTPException(400, "No files uploaded")

    all_chunks = []
    tmp_paths  = []

    try:
        # ── Step 1: load & chunk each file ────────────────────────────────
        for upload in files:
            suffix = os.path.splitext(upload.filename)[1].lower()
            if suffix not in (".pdf", ".docx", ".txt"):
                raise HTTPException(400, f"Unsupported file type: {upload.filename}")

            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                content = await upload.read()
                tmp.write(content)
                tmp_paths.append(tmp.name)

            try:
                chunks = load_and_chunk(tmp.name, chunk_size, chunk_overlap)
            except Exception as e:
                raise HTTPException(400, f"Could not read '{upload.filename}': {e}")

            for chunk in chunks:
                chunk.metadata["source"] = upload.filename
            all_chunks.extend(chunks)

    finally:
        for p in tmp_paths:
            try: os.unlink(p)
            except: pass

    if not all_chunks:
        raise HTTPException(400, "No text could be extracted from the uploaded files")

    # ── Step 2: embeddings ────────────────────────────────────────────────
    try:
        embeddings = get_embeddings()
    except Exception as e:
        raise HTTPException(500, f"Failed to load embedding model: {e}")

    # ── Step 3: vector store ──────────────────────────────────────────────
    try:
        vector_store_ = get_or_build_store(all_chunks, embeddings, vector_store)
    except Exception as e:
        raise HTTPException(500, f"Failed to build vector store: {e}")

    # ── Step 4: LLM ───────────────────────────────────────────────────────
    try:
        llm = get_llm(llm_provider)
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(500, f"Failed to load LLM: {e}")

    # ── Step 5: chains ────────────────────────────────────────────────────
    try:
        qa_chain   = build_qa_chain(vector_store_, llm, top_k)
        conv_chain = build_conversational_chain(vector_store_, llm, top_k)
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(500, f"Failed to build chains: {e}")
    stats      = get_document_stats(all_chunks)

    _state.update({
        "indexed":      True,
        "all_chunks":   all_chunks,
        "vector_store": vector_store_,
        "llm":          llm,
        "embeddings":   embeddings,
        "qa_chain":     qa_chain,
        "conv_chain":   conv_chain,
        "stats":        stats,
    })

    return {"message": "Indexed successfully", "stats": stats}


@app.post("/api/ask")
def ask(req: AskRequest):
    if not _state["indexed"]:
        raise HTTPException(400, "No documents indexed. Upload files first.")

    try:
        if req.mode == "conv":
            result = ask_with_memory(_state["conv_chain"], req.question)
        else:
            result = ask_question(_state["qa_chain"], req.question)
    except Exception as e:
        raise HTTPException(500, f"Failed to generate answer: {e}")

    scored_sources = check_source_relevance(req.question, result["sources"])
    confidence     = score_answer_confidence(result["answer"], scored_sources)

    return {
        "answer":     result["answer"],
        "sources":    scored_sources,
        "confidence": confidence,
    }


@app.post("/api/summarize")
def summarize(req: SummarizeRequest):
    if not _state["indexed"]:
        raise HTTPException(400, "No documents indexed. Upload files first.")

    try:
        docs = _state["all_chunks"]
        llm  = _state["llm"]
        if req.summary_type == "short":
            text = summarize_short(docs, llm)
        elif req.summary_type == "detailed":
            text = summarize_detailed(docs, llm)
        elif req.summary_type == "topics":
            text = extract_key_topics(docs, llm)
        else:
            raise HTTPException(400, f"Unknown summary_type: {req.summary_type}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Summarization failed: {e}")

    return {"summary": text, "summary_type": req.summary_type}


@app.post("/api/benchmark")
def benchmark():
    if not _state["indexed"]:
        raise HTTPException(400, "No documents indexed. Upload files first.")

    try:
        results = run_benchmark(_state["qa_chain"])
    except Exception as e:
        raise HTTPException(500, f"Benchmark failed: {e}")

    return {"results": results}


@app.post("/api/clear-memory")
def clear_conv_memory():
    if _state["conv_chain"]:
        clear_memory(_state["conv_chain"])
    return {"message": "Memory cleared"}


# ── Serve frontend ─────────────────────────────────────────────────────────
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "frontend")

if os.path.isdir(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/")
    def serve_index():
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

    @app.get("/{path:path}")
    def serve_static(path: str):
        full = os.path.join(FRONTEND_DIR, path)
        if os.path.isfile(full):
            return FileResponse(full)
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


# ── Entry point (fixes Windows multiprocessing issue) ─────────────────────
if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    import uvicorn
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=False)
