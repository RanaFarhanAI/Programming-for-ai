# DocuMind — Complete Reference Document
> Retrieval-Augmented Generation (RAG) Q&A System

---

## Table of Contents
1. [Project Overview](#1-project-overview)
2. [Architecture](#2-architecture)
3. [Project Structure](#3-project-structure)
4. [Tech Stack](#4-tech-stack)
5. [Installation](#5-installation)
6. [How to Run](#6-how-to-run)
7. [API Reference](#7-api-reference)
8. [Module Reference](#8-module-reference)
9. [Frontend Reference](#9-frontend-reference)
10. [Configuration](#10-configuration)
11. [Key Concepts](#11-key-concepts)
12. [Reuse in Other Projects](#12-reuse-in-other-projects)

---

## 1. Project Overview

DocuMind is a **Retrieval-Augmented Generation (RAG)** system that:
- Accepts PDF, DOCX, or TXT documents
- Splits them into chunks and stores embeddings in a vector database
- Answers natural language questions by retrieving relevant chunks and passing them to an LLM
- Provides a web UI (HTML/CSS/JS) served by a FastAPI backend

---

## 2. Architecture

```
User Question
     │
     ▼
[Embedding Model]          sentence-transformers/all-MiniLM-L6-v2
     │                     Converts text → 384-dim vectors
     ▼
[Vector Store]             FAISS or ChromaDB
     │                     Finds top-K most similar chunks
     ▼
[Context Assembly]         Concatenates retrieved chunks
     │
     ▼
[LLM]                      FLAN-T5 (free/local) or GPT-3.5 (OpenAI)
     │                     Generates answer from context + question
     ▼
Answer + Sources + Confidence Score
```

### RAG Flow (step by step)
1. **Ingest** — Load file → extract text → split into overlapping chunks
2. **Embed** — Convert each chunk to a vector using sentence-transformers
3. **Store** — Save vectors in FAISS index (saved to `faiss_index/` folder)
4. **Query** — Embed the question → find top-K similar chunks
5. **Generate** — Feed chunks as context to LLM → get grounded answer

---

## 3. Project Structure

```
document-qa-rag/
│
├── api.py                  FastAPI backend — REST endpoints + serves frontend
├── app.py                  Legacy Streamlit UI (optional)
├── cli.py                  Command-line interface
├── Makefile                Shortcut commands
├── requirements.txt        Python dependencies
├── .env.example            Environment variable template
│
├── frontend/               Web UI (pure HTML/CSS/JS)
│   ├── index.html          Single-page app with 5 tabs
│   ├── style.css           Dark theme design system
│   └── app.js              All interactivity + API calls
│
├── src/                    Core Python modules
│   ├── config.py           Central config from .env
│   ├── document_loader.py  File loading + text chunking
│   ├── vector_store.py     FAISS + ChromaDB management
│   ├── llm_provider.py     LLM factory (HuggingFace / OpenAI)
│   ├── qa_chain.py         Single-turn RAG chain
│   ├── memory.py           Conversational chain with history
│   ├── summarizer.py       Document summarization
│   ├── evaluator.py        Confidence scoring + benchmarks
│   └── utils.py            Export, timing, helpers
│
├── sample_data/
│   ├── sample.txt          AI/ML overview document
│   └── legal_sample.txt    Software license agreement
│
└── tests/                  Unit tests (pytest)
    ├── test_document_loader.py
    ├── test_evaluator.py
    ├── test_qa_chain.py
    ├── test_utils.py
    └── test_vector_store.py
```

---

## 4. Tech Stack

| Layer | Technology | Purpose |
|---|---|---|
| Backend API | FastAPI | REST endpoints, file upload, CORS |
| Web Server | Uvicorn | ASGI server for FastAPI |
| Frontend | HTML + CSS + JS | Single-page app, no framework |
| Embeddings | sentence-transformers | Text → vector conversion |
| Vector DB | FAISS | Fast similarity search (local file) |
| Vector DB alt | ChromaDB | Persistent vector database |
| LLM (free) | google/flan-t5-base | Local seq2seq model |
| LLM (paid) | OpenAI GPT-3.5-turbo | Cloud API |
| LLM Framework | LangChain Core | Chain/prompt abstractions |
| File Parsing | PyPDF2, python-docx | PDF and DOCX reading |
| Testing | pytest | Unit tests |

---

## 5. Installation

```bash
# 1. Clone / navigate to project
cd document-qa-rag

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up environment
copy .env.example .env
```

### Minimum install (just to run the server)
```bash
pip install fastapi uvicorn python-multipart python-dotenv
pip install langchain-core langchain-community
pip install sentence-transformers faiss-cpu
pip install transformers==4.41.2 torch
pip install PyPDF2 python-docx
```

---

## 6. How to Run

### Web App (recommended)
```bash
# Step 1 — navigate to project folder
cd "C:\Users\DELL\Desktop\PAI (LAB) Final\task 10\document-qa-rag"

# Step 2 — start the server
python api.py

# Step 3 — open browser (do NOT type this in PowerShell)
# Go to: http://localhost:8000
```

### CLI
```bash
# Interactive mode
python cli.py --file sample_data/sample.txt

# Single question
python cli.py --file sample_data/sample.txt --question "What is ML?"

# Conversational mode
python cli.py --file sample_data/sample.txt --mode conv

# Summarize
python cli.py --file sample_data/sample.txt --summarize

# Benchmark
python cli.py --file sample_data/sample.txt --benchmark
```

### Run Tests
```bash
pytest tests/ -v
```

---

## 7. API Reference

Base URL: `http://localhost:8000`

---

### GET `/api/status`
Check if documents are indexed.

**Response:**
```json
{
  "indexed": true,
  "sources": ["assignment2.docx"]
}
```

---

### POST `/api/index`
Upload and index documents.

**Request:** `multipart/form-data`

| Field | Type | Default | Description |
|---|---|---|---|
| `files` | File[] | required | PDF, DOCX, or TXT files |
| `llm_provider` | string | `huggingface` | `huggingface` or `openai` |
| `vector_store` | string | `faiss` | `faiss` or `chroma` |
| `chunk_size` | int | `500` | Characters per chunk |
| `chunk_overlap` | int | `50` | Overlap between chunks |
| `top_k` | int | `4` | Chunks to retrieve per query |

**Response:**
```json
{
  "message": "Indexed successfully",
  "stats": {
    "total_chunks": 42,
    "total_characters": 21000,
    "avg_chunk_size": 500,
    "estimated_words": 4200,
    "sources": ["assignment2.docx"]
  }
}
```

---

### POST `/api/ask`
Ask a question about indexed documents.

**Request:** `application/json`
```json
{
  "question": "What is machine learning?",
  "mode": "single",
  "top_k": 4
}
```

| Field | Type | Default | Description |
|---|---|---|---|
| `question` | string | required | The question to ask |
| `mode` | string | `single` | `single` or `conv` (conversational) |
| `top_k` | int | `4` | Number of chunks to retrieve |

**Response:**
```json
{
  "answer": "Machine learning is a subset of AI...",
  "sources": [
    {
      "source": "assignment2.docx",
      "chunk_index": 3,
      "chunk": "Machine learning enables systems...",
      "relevance_pct": 85,
      "keyword_matches": 3
    }
  ],
  "confidence": {
    "score": 90,
    "label": "High",
    "flags": []
  }
}
```

---

### POST `/api/summarize`
Generate a summary of indexed documents.

**Request:** `application/json`
```json
{
  "summary_type": "short"
}
```

| `summary_type` | Description |
|---|---|
| `short` | One paragraph summary |
| `detailed` | Bullet-point summary |
| `topics` | Numbered list of key topics |

**Response:**
```json
{
  "summary": "This document covers...",
  "summary_type": "short"
}
```

---

### POST `/api/benchmark`
Run preset benchmark questions.

**Response:**
```json
{
  "results": [
    {
      "question": "What is machine learning?",
      "answer": "...",
      "keyword_score": 75,
      "keyword_hits": ["learn", "data"],
      "confidence": { "score": 85, "label": "High", "flags": [] },
      "sources_count": 4
    }
  ]
}
```

---

### POST `/api/clear-memory`
Reset conversational memory.

**Response:**
```json
{ "message": "Memory cleared" }
```

---

## 8. Module Reference

### `src/document_loader.py`

```python
from src.document_loader import load_and_chunk, load_document, split_into_chunks

# Load a file and split into chunks
chunks = load_and_chunk("file.pdf", chunk_size=500, chunk_overlap=50)
# Returns: List[Document]  — each with .page_content and .metadata

# Load raw text only
text = load_document("file.pdf")

# Split existing text into chunks
chunks = split_into_chunks(text, source_name="file.pdf", chunk_size=500)
```

---

### `src/vector_store.py`

```python
from src.vector_store import get_embeddings, get_or_build_store, load_store, similarity_search

# Load embedding model (downloads ~90MB on first run)
embeddings = get_embeddings("all-MiniLM-L6-v2")

# Build or update vector store
store = get_or_build_store(chunks, embeddings, store_type="faiss")

# Load existing store from disk
store = load_store(embeddings, store_type="faiss")

# Search for similar chunks
results = similarity_search(store, "What is AI?", top_k=4)
# Returns: List[Tuple[Document, float]]  — (document, similarity_score)
```

---

### `src/llm_provider.py`

```python
from src.llm_provider import get_llm

# Free local model (no API key)
llm = get_llm("huggingface")

# OpenAI (requires OPENAI_API_KEY in .env)
llm = get_llm("openai")

# Call the LLM directly
answer = llm.invoke("What is machine learning?")
```

---

### `src/qa_chain.py`

```python
from src.qa_chain import build_qa_chain, ask_question

# Build the RAG chain
chain = build_qa_chain(vector_store, llm, top_k=4)

# Ask a question
result = ask_question(chain, "What is the main topic?")
# result = {
#   "answer": "...",
#   "sources": [{"source": "file.pdf", "chunk_index": 0, "chunk": "..."}]
# }
```

---

### `src/memory.py`

```python
from src.memory import build_conversational_chain, ask_with_memory, clear_memory

# Build chain with memory
chain = build_conversational_chain(vector_store, llm, top_k=4, memory_window=5)

# Ask follow-up questions
result1 = ask_with_memory(chain, "What is AI?")
result2 = ask_with_memory(chain, "Can you explain that further?")  # uses history

# Clear memory
clear_memory(chain)
```

---

### `src/summarizer.py`

```python
from src.summarizer import summarize_short, summarize_detailed, extract_key_topics, get_document_stats

summary  = summarize_short(chunks, llm)       # one paragraph
bullets  = summarize_detailed(chunks, llm)    # bullet points
topics   = extract_key_topics(chunks, llm)    # numbered list
stats    = get_document_stats(chunks)
# stats = {"total_chunks": 42, "estimated_words": 4200, "sources": [...]}
```

---

### `src/evaluator.py`

```python
from src.evaluator import score_answer_confidence, check_source_relevance, run_benchmark

# Score an answer
conf = score_answer_confidence(answer, sources)
# conf = {"score": 85, "label": "High", "flags": []}

# Rank sources by relevance to question
ranked = check_source_relevance("What is AI?", sources)
# adds "relevance_pct" and "keyword_matches" to each source

# Run benchmark
results = run_benchmark(chain)
```

---

### `src/utils.py`

```python
from src.utils import export_chat_history, export_to_markdown, clean_text, truncate, Timer

# Export Q&A history
export_chat_history(history, "output.json")
export_to_markdown(history, "output.md")

# Time an operation
with Timer("Embedding"):
    embeddings = get_embeddings()
# prints: [Timer] Embedding: 1.23s

# Text helpers
clean_text("Hello   \n\n\n World")   # → "Hello\n\nWorld"
truncate("long text...", max_chars=100)
```

---

## 9. Frontend Reference

### Tab Structure

| Tab | Route | Purpose |
|---|---|---|
| Upload | default | Upload files, index documents, view stats |
| Q&A | `data-tab="qa"` | Chat interface with confidence scores |
| Summarize | `data-tab="summary"` | Generate short/detailed/topics summary |
| Evaluate | `data-tab="evaluate"` | Run benchmark, view scores |
| Export | `data-tab="export"` | Download history as JSON or Markdown |

### JavaScript API calls (`frontend/app.js`)

```javascript
// Index documents
POST /api/index          FormData with files + settings

// Ask a question
POST /api/ask            JSON { question, mode, top_k }

// Summarize
POST /api/summarize      JSON { summary_type }

// Benchmark
POST /api/benchmark      (no body)

// Clear memory
POST /api/clear-memory   (no body)

// Check status
GET  /api/status
```

### CSS Variables (for reuse in other projects)

```css
--bg:          #0f1117   /* main background */
--bg2:         #161b27   /* card background */
--bg3:         #1e2535   /* input background */
--border:      #2a3347   /* border color */
--accent:      #4f8ef7   /* primary blue */
--green:       #2ecc71   /* success */
--yellow:      #f39c12   /* warning */
--red:         #e74c3c   /* error */
--text:        #e8eaf0   /* primary text */
--text2:       #8b95a8   /* secondary text */
--text3:       #5a6478   /* muted text */
```

---

## 10. Configuration

### `.env` file

```env
# LLM
LLM_PROVIDER=huggingface          # huggingface | openai
HF_MODEL_NAME=google/flan-t5-base # any seq2seq HuggingFace model
OPENAI_API_KEY=sk-...             # only needed for openai

# Embeddings
EMBEDDING_MODEL=all-MiniLM-L6-v2  # any sentence-transformer model

# Vector Store
VECTOR_STORE=faiss                 # faiss | chroma
FAISS_INDEX_PATH=faiss_index       # folder to save FAISS index
CHROMA_DB_PATH=chroma_db           # folder to save ChromaDB

# Chunking
CHUNK_SIZE=500                     # characters per chunk
CHUNK_OVERLAP=50                   # overlap between chunks

# Retrieval
TOP_K=4                            # chunks retrieved per query
MEMORY_WINDOW=5                    # past Q&A pairs kept in memory
```

---

## 11. Key Concepts

### Chunking
Long documents are split into overlapping pieces so the embedding model can handle them. Overlap ensures context isn't lost at chunk boundaries.

```
[chunk 1: chars 0-500]
         [chunk 2: chars 450-950]   ← 50 char overlap
                  [chunk 3: chars 900-1400]
```

### Embeddings
Each chunk is converted to a fixed-size vector (384 dimensions with `all-MiniLM-L6-v2`). Similar text produces similar vectors — this is how relevant chunks are found.

### FAISS Index
Facebook AI Similarity Search — stores all chunk vectors in a file (`faiss_index/`). At query time, finds the top-K closest vectors to the question vector in milliseconds.

### RAG vs Pure LLM
| | Pure LLM | RAG |
|---|---|---|
| Knowledge source | Training data | Your documents |
| Hallucination | Common | Reduced (grounded) |
| Up-to-date info | No | Yes |
| Source citations | No | Yes |

### Confidence Score
Heuristic score (0–100) based on:
- Answer length (short = low confidence)
- Uncertainty phrases detected ("I don't know...")
- Number of source chunks retrieved
- Source diversity

---

## 12. Reuse in Other Projects

### Copy just the RAG core (3 files)

```python
# Minimum needed for RAG in any project:
from src.document_loader import load_and_chunk
from src.vector_store    import get_embeddings, get_or_build_store
from src.qa_chain        import build_qa_chain, ask_question

# Full pipeline in 5 lines:
chunks      = load_and_chunk("your_file.pdf")
embeddings  = get_embeddings()
store       = get_or_build_store(chunks, embeddings, "faiss")
llm         = get_llm("huggingface")
chain       = build_qa_chain(store, llm)

result = ask_question(chain, "Your question here")
print(result["answer"])
```

### Add to an existing FastAPI app

```python
# In your existing FastAPI app:
from src.document_loader import load_and_chunk
from src.vector_store    import get_embeddings, get_or_build_store
from src.llm_provider    import get_llm
from src.qa_chain        import build_qa_chain, ask_question

@app.post("/qa")
async def qa_endpoint(question: str, file: UploadFile):
    chunks    = load_and_chunk(file)
    store     = get_or_build_store(chunks, get_embeddings())
    chain     = build_qa_chain(store, get_llm())
    return ask_question(chain, question)
```

### Swap the LLM

```python
# Use OpenAI instead of HuggingFace
llm = get_llm("openai")   # set OPENAI_API_KEY in .env

# Use a better free model
# In .env: HF_MODEL_NAME=google/flan-t5-large
llm = get_llm("huggingface")
```

### Swap the Vector Store

```python
# Use ChromaDB instead of FAISS (persistent across restarts)
store = get_or_build_store(chunks, embeddings, store_type="chroma")
```

### Use conversational memory

```python
from src.memory import build_conversational_chain, ask_with_memory

chain = build_conversational_chain(store, llm, memory_window=5)

# Each call remembers previous questions
r1 = ask_with_memory(chain, "What is AI?")
r2 = ask_with_memory(chain, "Give me an example")  # knows context
```

---

## Common Errors & Fixes

| Error | Cause | Fix |
|---|---|---|
| `No module named 'fastapi'` | Not installed | `pip install fastapi uvicorn python-multipart` |
| `No module named 'faiss'` | Not installed | `pip install faiss-cpu` |
| `No module named 'docx'` | Not installed | `pip install python-docx` |
| `No module named 'sentence_transformers'` | Not installed | `pip install sentence-transformers` |
| `Unknown task text2text-generation` | transformers 5.x | `pip install transformers==4.41.2` |
| `Failed to fetch` | Server not running | Run `python api.py` first |
| `ERR_CONNECTION_REFUSED` | Server not running | Run `python api.py` first |
| `localhost refused to connect` | Server not running | Run `python api.py` first |
| `Internal Server Error` | Check PowerShell terminal | Full traceback printed there |

---

*Generated from DocuMind v1.0 — Document Q&A RAG System*
