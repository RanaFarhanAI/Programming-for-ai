
"""
app.py
------
Streamlit web UI for the Document Q&A RAG system.
Features:
  - Upload PDF / DOCX / TXT files
  - Single Q&A (no memory) or Conversational mode (with memory)
  - Document summarization (short / detailed / topics)
  - Answer confidence scoring & source relevance
  - Benchmark runner
  - Export chat history (JSON / Markdown)
"""

import os
import tempfile
import streamlit as st
from dotenv import load_dotenv

from src.document_loader import load_and_chunk
from src.vector_store import get_embeddings, get_or_build_store, load_store
from src.llm_provider import get_llm
from src.qa_chain import build_qa_chain, ask_question
from src.memory import build_conversational_chain, ask_with_memory, clear_memory
from src.summarizer import summarize_short, summarize_detailed, extract_key_topics, get_document_stats
from src.evaluator import score_answer_confidence, check_source_relevance, run_benchmark
from src.utils import export_chat_history, export_to_markdown, clear_vector_store, Timer

load_dotenv()

# ─── Page Config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Document Q&A (RAG)",
    page_icon="📄",
    layout="wide"
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
.confidence-high   { color: #2ecc71; font-weight: bold; }
.confidence-medium { color: #f39c12; font-weight: bold; }
.confidence-low    { color: #e74c3c; font-weight: bold; }
.source-box { background: #f8f9fa; border-left: 3px solid #4a90d9;
              padding: 8px 12px; border-radius: 4px; margin: 4px 0; }
</style>
""", unsafe_allow_html=True)

st.title("📄 Document Q&A System (RAG)")
st.markdown("Upload **PDF, DOCX, or TXT** files and ask questions about their content.")

# ─── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Settings")

    llm_provider = st.selectbox(
        "LLM Provider",
        ["huggingface", "openai"],
        help="HuggingFace is free and runs locally. OpenAI requires an API key."
    )

    vector_store_type = st.selectbox(
        "Vector Store",
        ["faiss", "chroma"],
        help="FAISS is faster. ChromaDB persists across sessions."
    )

    mode = st.radio(
        "Q&A Mode",
        ["Single Q&A", "Conversational (Memory)"],
        help="Conversational mode remembers previous questions."
    )

    top_k = st.slider("Top-K Chunks", 1, 10, 4)
    chunk_size = st.slider("Chunk Size", 100, 1000, 500, 50)
    chunk_overlap = st.slider("Chunk Overlap", 0, 200, 50, 10)

    st.markdown("---")
    st.markdown("**Models:**")
    st.markdown("- Embeddings: `all-MiniLM-L6-v2`")
    st.markdown("- LLM (HF): `google/flan-t5-base`")
    st.markdown("- LLM (OpenAI): `gpt-3.5-turbo`")

    st.markdown("---")
    if st.button("🗑️ Clear Vector Store"):
        clear_vector_store(vector_store_type)
        st.success("Vector store cleared.")

# ─── Session State ────────────────────────────────────────────────────────────
for key, default in {
    "qa_chain": None,
    "conv_chain": None,
    "chat_history": [],
    "indexed_files": [],
    "all_chunks": [],
    "llm": None,
    "embeddings": None,
    "vector_store": None
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

# ─── Tabs ─────────────────────────────────────────────────────────────────────
tab_upload, tab_qa, tab_summary, tab_eval, tab_export = st.tabs([
    "📥 Upload", "💬 Q&A", "📋 Summarize", "📊 Evaluate", "💾 Export"
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — UPLOAD & INDEX
# ══════════════════════════════════════════════════════════════════════════════
with tab_upload:
    st.subheader("Upload & Index Documents")

    uploaded_files = st.file_uploader(
        "Choose files (PDF, DOCX, TXT)",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True
    )

    col1, col2 = st.columns(2)

    with col1:
        if uploaded_files and st.button("📥 Index Documents", type="primary"):
            with st.spinner("Loading, chunking, and embedding documents..."):
                try:
                    all_chunks = []
                    progress = st.progress(0)

                    for idx, uploaded_file in enumerate(uploaded_files):
                        suffix = os.path.splitext(uploaded_file.name)[1]
                        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                            tmp.write(uploaded_file.read())
                            tmp_path = tmp.name

                        with Timer(f"Load {uploaded_file.name}"):
                            chunks = load_and_chunk(tmp_path, chunk_size, chunk_overlap)

                        for chunk in chunks:
                            chunk.metadata["source"] = uploaded_file.name
                        all_chunks.extend(chunks)
                        os.unlink(tmp_path)

                        if uploaded_file.name not in st.session_state.indexed_files:
                            st.session_state.indexed_files.append(uploaded_file.name)

                        progress.progress((idx + 1) / len(uploaded_files))

                    # Build embeddings + vector store
                    with Timer("Build embeddings"):
                        embeddings = get_embeddings()
                        vector_store = get_or_build_store(all_chunks, embeddings, vector_store_type)

                    # Build LLM + chains
                    with Timer("Load LLM"):
                        llm = get_llm(llm_provider)

                    st.session_state.all_chunks    = all_chunks
                    st.session_state.embeddings    = embeddings
                    st.session_state.vector_store  = vector_store
                    st.session_state.llm           = llm
                    st.session_state.qa_chain      = build_qa_chain(vector_store, llm, top_k)
                    st.session_state.conv_chain    = build_conversational_chain(vector_store, llm, top_k)

                    stats = get_document_stats(all_chunks)
                    st.success(f"✅ Indexed **{stats['total_chunks']} chunks** from **{len(uploaded_files)} file(s)**")

                    # Show stats
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Total Chunks", stats["total_chunks"])
                    c2.metric("Est. Words", f"{stats['estimated_words']:,}")
                    c3.metric("Avg Chunk Size", f"{stats['avg_chunk_size']} chars")

                except Exception as e:
                    st.error(f"❌ Error: {e}")

    with col2:
        if st.session_state.indexed_files:
            st.markdown("**Indexed Files:**")
            for f in st.session_state.indexed_files:
                st.markdown(f"- 📄 `{f}`")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — Q&A
# ══════════════════════════════════════════════════════════════════════════════
with tab_qa:
    st.subheader("Ask Questions")

    if not st.session_state.qa_chain:
        st.info("⬆️ Please upload and index a document in the **Upload** tab first.")
    else:
        # Mode indicator
        if mode == "Conversational (Memory)":
            st.markdown("🧠 **Conversational mode** — follow-up questions are supported.")
        else:
            st.markdown("🔍 **Single Q&A mode** — each question is independent.")

        question = st.text_input(
            "Your question",
            placeholder="e.g. What are the main topics covered in this document?"
        )

        col_ask, col_clear = st.columns([3, 1])

        with col_ask:
            ask_btn = st.button("🔍 Get Answer", type="primary")

        with col_clear:
            if st.button("🗑️ Clear History"):
                st.session_state.chat_history = []
                if st.session_state.conv_chain:
                    clear_memory(st.session_state.conv_chain)
                st.rerun()

        if ask_btn and question:
            with st.spinner("Retrieving and generating answer..."):
                try:
                    with Timer("QA"):
                        if mode == "Conversational (Memory)":
                            result = ask_with_memory(st.session_state.conv_chain, question)
                        else:
                            result = ask_question(st.session_state.qa_chain, question)

                    # Score confidence
                    confidence = score_answer_confidence(result["answer"], result["sources"])
                    # Score source relevance
                    scored_sources = check_source_relevance(question, result["sources"])

                    st.session_state.chat_history.append({
                        "question": question,
                        "answer": result["answer"],
                        "sources": scored_sources,
                        "confidence": confidence
                    })

                except Exception as e:
                    st.error(f"❌ Error: {e}")

        # ── Display chat history ──
        if st.session_state.chat_history:
            for item in reversed(st.session_state.chat_history):
                with st.container():
                    st.markdown(f"**❓ {item['question']}**")

                    # Confidence badge
                    conf = item.get("confidence", {})
                    label = conf.get("label", "")
                    score = conf.get("score", 0)
                    css_class = f"confidence-{label.lower()}"
                    st.markdown(
                        f"<span class='{css_class}'>Confidence: {label} ({score}/100)</span>",
                        unsafe_allow_html=True
                    )

                    st.success(f"💡 {item['answer']}")

                    # Flags
                    if conf.get("flags"):
                        for flag in conf["flags"]:
                            st.warning(f"⚠️ {flag}")

                    # Sources
                    with st.expander(f"📎 Sources ({len(item['sources'])} chunks)"):
                        for j, src in enumerate(item["sources"]):
                            relevance = src.get("relevance_pct", 0)
                            st.markdown(
                                f"<div class='source-box'>"
                                f"<b>Source {j+1}:</b> <code>{src['source']}</code> "
                                f"— Chunk #{src['chunk_index']} "
                                f"— Relevance: <b>{relevance}%</b>"
                                f"</div>",
                                unsafe_allow_html=True
                            )
                            st.text(src["chunk"])

                st.markdown("---")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — SUMMARIZE
# ══════════════════════════════════════════════════════════════════════════════
with tab_summary:
    st.subheader("Document Summarization")

    if not st.session_state.all_chunks:
        st.info("⬆️ Please upload and index a document first.")
    else:
        stats = get_document_stats(st.session_state.all_chunks)
        c1, c2, c3 = st.columns(3)
        c1.metric("Chunks", stats["total_chunks"])
        c2.metric("Est. Words", f"{stats['estimated_words']:,}")
        c3.metric("Files", len(stats["sources"]))

        summary_type = st.radio(
            "Summary Type",
            ["Short (paragraph)", "Detailed (bullet points)", "Key Topics"],
            horizontal=True
        )

        if st.button("📋 Generate Summary", type="primary"):
            with st.spinner("Generating summary..."):
                try:
                    llm = st.session_state.llm
                    docs = st.session_state.all_chunks

                    with Timer("Summarize"):
                        if summary_type == "Short (paragraph)":
                            summary = summarize_short(docs, llm)
                        elif summary_type == "Detailed (bullet points)":
                            summary = summarize_detailed(docs, llm)
                        else:
                            summary = extract_key_topics(docs, llm)

                    st.markdown("### Summary")
                    st.write(summary)

                except Exception as e:
                    st.error(f"❌ Error: {e}")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — EVALUATE
# ══════════════════════════════════════════════════════════════════════════════
with tab_eval:
    st.subheader("Benchmark Evaluation")
    st.markdown("Run a set of test questions and measure answer quality.")

    if not st.session_state.qa_chain:
        st.info("⬆️ Please upload and index a document first.")
    else:
        st.markdown("**Default benchmark uses the included `sample.txt` (AI/ML topics).**")
        st.markdown("Questions tested:")
        benchmark_questions = [
            "What is machine learning?",
            "What are the types of machine learning?",
            "What is deep learning used for?",
            "What are the challenges in AI?",
            "What is NLP?"
        ]
        for q in benchmark_questions:
            st.markdown(f"- {q}")

        if st.button("▶️ Run Benchmark", type="primary"):
            with st.spinner("Running benchmark questions..."):
                try:
                    results = run_benchmark(st.session_state.qa_chain)

                    # Summary metrics
                    avg_kw = sum(r["keyword_score"] for r in results) / len(results)
                    avg_conf = sum(r["confidence"]["score"] for r in results) / len(results)

                    st.markdown("### Results")
                    c1, c2 = st.columns(2)
                    c1.metric("Avg Keyword Score", f"{avg_kw:.1f}%")
                    c2.metric("Avg Confidence", f"{avg_conf:.1f}/100")

                    for i, r in enumerate(results):
                        with st.expander(f"Q{i+1}: {r['question']}"):
                            st.markdown(f"**Answer:** {r['answer']}")
                            st.markdown(f"**Keyword Score:** {r['keyword_score']}%")
                            st.markdown(f"**Confidence:** {r['confidence']['label']} ({r['confidence']['score']}/100)")
                            st.markdown(f"**Keywords found:** {', '.join(r['keyword_hits']) or 'none'}")
                            st.markdown(f"**Sources retrieved:** {r['sources_count']}")

                except Exception as e:
                    st.error(f"❌ Error: {e}")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — EXPORT
# ══════════════════════════════════════════════════════════════════════════════
with tab_export:
    st.subheader("Export Chat History")

    if not st.session_state.chat_history:
        st.info("No Q&A history yet. Ask some questions in the **Q&A** tab first.")
    else:
        st.markdown(f"**{len(st.session_state.chat_history)} Q&A pair(s)** ready to export.")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("📄 Export as JSON"):
                path = export_chat_history(st.session_state.chat_history)
                with open(path, "r") as f:
                    st.download_button(
                        "⬇️ Download JSON",
                        data=f.read(),
                        file_name=os.path.basename(path),
                        mime="application/json"
                    )

        with col2:
            if st.button("📝 Export as Markdown"):
                path = export_to_markdown(st.session_state.chat_history)
                with open(path, "r") as f:
                    st.download_button(
                        "⬇️ Download Markdown",
                        data=f.read(),
                        file_name=os.path.basename(path),
                        mime="text/markdown"
                    )

        st.markdown("### Preview")
        for i, item in enumerate(st.session_state.chat_history, 1):
            st.markdown(f"**Q{i}:** {item['question']}")
            st.markdown(f"**A{i}:** {item['answer']}")
            st.markdown("---")
