/**
 * app.js — DocuMind Frontend
 * Talks to the FastAPI backend at /api/*
 */

const API = 'http://localhost:8000/api';

// ── State ──────────────────────────────────────────────────────────────────
const state = {
  indexed: false,
  files: [],          // File objects queued for upload
  chatHistory: [],    // { question, answer, sources, confidence }
  selectedSummaryType: 'short',
};

// ── DOM refs ───────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

const els = {
  sidebar:        $('sidebar'),
  sidebarToggle:  $('sidebarToggle'),
  uploadZone:     $('uploadZone'),
  fileInput:      $('fileInput'),
  fileQueue:      $('fileQueue'),
  indexBtn:       $('indexBtn'),
  statsGrid:      $('statsGrid'),
  statChunks:     $('statChunks'),
  statWords:      $('statWords'),
  statFiles:      $('statFiles'),
  statAvgChunk:   $('statAvgChunk'),
  uploadSuccess:  $('uploadSuccess'),
  uploadError:    $('uploadError'),
  indexedList:    $('indexedList'),

  qaBanner:       $('qaBanner'),
  chatMessages:   $('chatMessages'),
  questionInput:  $('questionInput'),
  askBtn:         $('askBtn'),
  clearChatBtn:   $('clearChatBtn'),
  charCount:      $('charCount'),
  modeBadge:      $('modeBadge'),

  summarizeBtn:   $('summarizeBtn'),
  summaryResult:  $('summaryResult'),
  summaryText:    $('summaryText'),
  summaryTypeLabel: $('summaryTypeLabel'),
  copySummaryBtn: $('copySummaryBtn'),
  summaryError:   $('summaryError'),

  benchmarkBtn:   $('benchmarkBtn'),
  benchmarkResults: $('benchmarkResults'),
  bmAvgKeyword:   $('bmAvgKeyword'),
  bmAvgConfidence:$('bmAvgConfidence'),
  bmTotal:        $('bmTotal'),
  bmItems:        $('bmItems'),
  benchmarkError: $('benchmarkError'),

  exportEmpty:    $('exportEmpty'),
  exportContent:  $('exportContent'),
  exportCount:    $('exportCount'),
  exportJsonBtn:  $('exportJsonBtn'),
  exportMdBtn:    $('exportMdBtn'),
  exportPreviewList: $('exportPreviewList'),

  globalLoader:   $('globalLoader'),
  loaderText:     $('loaderText'),
  toast:          $('toast'),

  llmProvider:    $('llmProvider'),
  vectorStore:    $('vectorStore'),
  qaMode:         $('qaMode'),
  topK:           $('topK'),
  topKVal:        $('topKVal'),
  chunkSize:      $('chunkSize'),
  chunkSizeVal:   $('chunkSizeVal'),
};

// ── Tab Navigation ─────────────────────────────────────────────────────────
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    $(`tab-${tab}`).classList.add('active');

    if (tab === 'qa')     refreshQATab();
    if (tab === 'export') refreshExportTab();
  });
});

// ── Sidebar Toggle ─────────────────────────────────────────────────────────
els.sidebarToggle.addEventListener('click', () => {
  els.sidebar.classList.toggle('collapsed');
});

// ── Settings sliders ───────────────────────────────────────────────────────
els.topK.addEventListener('input', () => { els.topKVal.textContent = els.topK.value; });
els.chunkSize.addEventListener('input', () => { els.chunkSizeVal.textContent = els.chunkSize.value; });

els.qaMode.addEventListener('change', () => {
  const conv = els.qaMode.value === 'conv';
  els.modeBadge.textContent = conv ? '🧠 Conversational (Memory)' : '🔍 Single Q&A';
});

// ── Upload Zone ────────────────────────────────────────────────────────────
els.uploadZone.addEventListener('click', () => els.fileInput.click());

els.uploadZone.addEventListener('dragover', e => {
  e.preventDefault();
  els.uploadZone.classList.add('drag-over');
});
els.uploadZone.addEventListener('dragleave', () => els.uploadZone.classList.remove('drag-over'));
els.uploadZone.addEventListener('drop', e => {
  e.preventDefault();
  els.uploadZone.classList.remove('drag-over');
  addFiles([...e.dataTransfer.files]);
});

els.fileInput.addEventListener('change', () => {
  addFiles([...els.fileInput.files]);
  els.fileInput.value = '';
});

function addFiles(newFiles) {
  const allowed = ['application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'];
  const extAllowed = ['.pdf', '.docx', '.txt'];

  newFiles.forEach(f => {
    const ext = f.name.slice(f.name.lastIndexOf('.')).toLowerCase();
    if (!extAllowed.includes(ext)) {
      showToast(`❌ Unsupported: ${f.name}`, 'error');
      return;
    }
    if (!state.files.find(x => x.name === f.name)) {
      state.files.push(f);
    }
  });
  renderFileQueue();
}

function renderFileQueue() {
  els.fileQueue.innerHTML = '';
  state.files.forEach((f, i) => {
    const ext = f.name.slice(f.name.lastIndexOf('.')).toLowerCase();
    const icon = ext === '.pdf' ? '📕' : ext === '.docx' ? '📘' : '📄';
    const size = f.size < 1024 * 1024
      ? `${(f.size / 1024).toFixed(1)} KB`
      : `${(f.size / 1024 / 1024).toFixed(1)} MB`;

    const item = document.createElement('div');
    item.className = 'file-item';
    item.innerHTML = `
      <span class="file-item-icon">${icon}</span>
      <span class="file-item-name">${f.name}</span>
      <span class="file-item-size">${size}</span>
      <button class="file-item-remove" data-idx="${i}" title="Remove">✕</button>
    `;
    els.fileQueue.appendChild(item);
  });

  els.indexBtn.disabled = state.files.length === 0;

  document.querySelectorAll('.file-item-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      state.files.splice(+btn.dataset.idx, 1);
      renderFileQueue();
    });
  });
}

// ── Index Documents ────────────────────────────────────────────────────────
els.indexBtn.addEventListener('click', async () => {
  if (!state.files.length) return;

  const formData = new FormData();
  state.files.forEach(f => formData.append('files', f));
  formData.append('llm_provider',   els.llmProvider.value);
  formData.append('vector_store',   els.vectorStore.value);
  formData.append('chunk_size',     els.chunkSize.value);
  formData.append('chunk_overlap',  '50');
  formData.append('top_k',          els.topK.value);

  showLoader('Indexing documents…');
  hideAlert(els.uploadSuccess);
  hideAlert(els.uploadError);

  try {
    const res = await fetch(`${API}/index`, { method: 'POST', body: formData });

    let data;
    try { data = await res.json(); }
    catch { throw new Error(`Server error (${res.status}) — check the terminal for details`); }

    if (!res.ok) throw new Error(data.detail || `Server error ${res.status}`);

    state.indexed = true;

    // Stats
    els.statsGrid.style.display = 'grid';
    els.statChunks.textContent   = data.stats.total_chunks.toLocaleString();
    els.statWords.textContent    = data.stats.estimated_words.toLocaleString();
    els.statFiles.textContent    = data.stats.sources.length;
    els.statAvgChunk.textContent = data.stats.avg_chunk_size;

    // Indexed files sidebar
    renderIndexedFiles(data.stats.sources);

    showAlert(els.uploadSuccess, `✅ Indexed ${data.stats.total_chunks} chunks from ${data.stats.sources.length} file(s).`);
    showToast('Documents indexed successfully!', 'success');

    state.files = [];
    renderFileQueue();

  } catch (err) {
    showAlert(els.uploadError, `❌ ${err.message}`);
    showToast(err.message, 'error');
  } finally {
    hideLoader();
  }
});

function renderIndexedFiles(sources) {
  els.indexedList.innerHTML = '';
  if (!sources || sources.length === 0) {
    els.indexedList.innerHTML = '<em>None yet</em>';
    return;
  }
  sources.forEach(src => {
    const ext = src.slice(src.lastIndexOf('.')).toLowerCase();
    const icon = ext === '.pdf' ? '📕' : ext === '.docx' ? '📘' : '📄';
    const div = document.createElement('div');
    div.className = 'indexed-file-item';
    div.innerHTML = `<span>${icon}</span><span title="${src}">${src}</span>`;
    els.indexedList.appendChild(div);
  });
}

// ── Q&A Tab ────────────────────────────────────────────────────────────────
function refreshQATab() {
  els.qaBanner.style.display = state.indexed ? 'none' : 'block';
}

// Character counter
els.questionInput.addEventListener('input', () => {
  const len = els.questionInput.value.length;
  els.charCount.textContent = `${len} / 500`;
  els.charCount.style.color = len > 450 ? 'var(--yellow)' : 'var(--text3)';
});

// Send on Enter (Shift+Enter = newline)
els.questionInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    els.askBtn.click();
  }
});

els.askBtn.addEventListener('click', async () => {
  const question = els.questionInput.value.trim();
  if (!question) return;
  if (!state.indexed) { showToast('Index a document first', 'error'); return; }

  // Append user bubble
  appendUserMessage(question);
  els.questionInput.value = '';
  els.charCount.textContent = '0 / 500';

  // Typing indicator
  const typingEl = appendTypingIndicator();

  try {
    const res = await fetch(`${API}/ask`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question,
        mode:     els.qaMode.value,
        top_k:    +els.topK.value,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Failed to get answer');

    typingEl.remove();
    appendBotMessage(data);

    state.chatHistory.push({
      question,
      answer:     data.answer,
      sources:    data.sources,
      confidence: data.confidence,
    });

  } catch (err) {
    typingEl.remove();
    appendErrorMessage(err.message);
  }
});

els.clearChatBtn.addEventListener('click', async () => {
  state.chatHistory = [];
  els.chatMessages.innerHTML = `
    <div class="chat-empty">
      <div class="chat-empty-icon">💬</div>
      <div>Ask your first question below</div>
    </div>`;
  // Also clear server-side memory
  try { await fetch(`${API}/clear-memory`, { method: 'POST' }); } catch {}
  showToast('Chat cleared', 'success');
});

function appendUserMessage(text) {
  removeEmpty();
  const div = document.createElement('div');
  div.className = 'msg msg-user';
  div.innerHTML = `<div class="msg-bubble">${escHtml(text)}</div>`;
  els.chatMessages.appendChild(div);
  scrollChat();
}

function appendBotMessage(data) {
  const conf = data.confidence || {};
  const label = (conf.label || 'Medium').toLowerCase();
  const score = conf.score ?? '—';

  const sourcesHtml = (data.sources || []).map((s, i) => `
    <div class="source-item">
      <div class="source-item-header">
        <span>📄 ${escHtml(s.source)} — Chunk #${s.chunk_index}</span>
        <span class="relevance-pill">${s.relevance_pct ?? '—'}% match</span>
      </div>
      <div>${escHtml(s.chunk)}</div>
    </div>`).join('');

  const div = document.createElement('div');
  div.className = 'msg msg-bot';
  div.innerHTML = `
    <div class="msg-bubble">${escHtml(data.answer)}</div>
    <div class="msg-meta">
      <span class="confidence-badge conf-${label}">
        ${label.charAt(0).toUpperCase() + label.slice(1)} confidence (${score}/100)
      </span>
      ${data.sources?.length
        ? `<button class="sources-toggle">📎 ${data.sources.length} source${data.sources.length > 1 ? 's' : ''}</button>`
        : ''}
    </div>
    ${data.sources?.length ? `<div class="sources-panel">${sourcesHtml}</div>` : ''}
  `;

  // Toggle sources
  const toggle = div.querySelector('.sources-toggle');
  const panel  = div.querySelector('.sources-panel');
  if (toggle && panel) {
    toggle.addEventListener('click', () => panel.classList.toggle('open'));
  }

  els.chatMessages.appendChild(div);
  scrollChat();
}

function appendErrorMessage(msg) {
  const div = document.createElement('div');
  div.className = 'msg msg-bot';
  div.innerHTML = `<div class="msg-bubble" style="color:var(--red)">❌ ${escHtml(msg)}</div>`;
  els.chatMessages.appendChild(div);
  scrollChat();
}

function appendTypingIndicator() {
  removeEmpty();
  const div = document.createElement('div');
  div.className = 'msg msg-bot';
  div.innerHTML = `
    <div class="typing-indicator">
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
      <div class="typing-dot"></div>
    </div>`;
  els.chatMessages.appendChild(div);
  scrollChat();
  return div;
}

function removeEmpty() {
  const empty = els.chatMessages.querySelector('.chat-empty');
  if (empty) empty.remove();
}

function scrollChat() {
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
}

// ── Summarize Tab ──────────────────────────────────────────────────────────
document.querySelectorAll('.summary-type-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.summary-type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.selectedSummaryType = btn.dataset.type;
  });
});

els.summarizeBtn.addEventListener('click', async () => {
  if (!state.indexed) { showToast('Index a document first', 'error'); return; }

  showLoader('Generating summary…');
  hideAlert(els.summaryError);
  els.summaryResult.style.display = 'none';

  try {
    const res = await fetch(`${API}/summarize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ summary_type: state.selectedSummaryType }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Summarization failed');

    const labels = { short: 'Short Summary', detailed: 'Detailed Summary', topics: 'Key Topics' };
    els.summaryTypeLabel.textContent = labels[state.selectedSummaryType] || 'Summary';
    els.summaryText.textContent = data.summary;
    els.summaryResult.style.display = 'block';

  } catch (err) {
    showAlert(els.summaryError, `❌ ${err.message}`);
  } finally {
    hideLoader();
  }
});

els.copySummaryBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(els.summaryText.textContent)
    .then(() => showToast('Copied to clipboard!', 'success'))
    .catch(() => showToast('Copy failed', 'error'));
});

// ── Benchmark Tab ──────────────────────────────────────────────────────────
els.benchmarkBtn.addEventListener('click', async () => {
  if (!state.indexed) { showToast('Index a document first', 'error'); return; }

  showLoader('Running benchmark…');
  hideAlert(els.benchmarkError);
  els.benchmarkResults.style.display = 'none';

  try {
    const res = await fetch(`${API}/benchmark`, { method: 'POST' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Benchmark failed');

    const results = data.results;
    const avgKw   = results.reduce((s, r) => s + r.keyword_score, 0) / results.length;
    const avgConf = results.reduce((s, r) => s + r.confidence.score, 0) / results.length;

    els.bmAvgKeyword.textContent    = `${avgKw.toFixed(1)}%`;
    els.bmAvgConfidence.textContent = `${avgConf.toFixed(1)}/100`;
    els.bmTotal.textContent         = results.length;

    els.bmItems.innerHTML = results.map((r, i) => `
      <div class="bm-item">
        <div class="bm-item-header" onclick="this.nextElementSibling.classList.toggle('open')">
          <span class="bm-item-q">Q${i+1}: ${escHtml(r.question)}</span>
          <div class="bm-item-scores">
            <span class="score-pill score-kw">KW: ${r.keyword_score}%</span>
            <span class="score-pill score-conf">Conf: ${r.confidence.score}/100</span>
          </div>
        </div>
        <div class="bm-item-body">
          <div class="bm-answer">${escHtml(r.answer)}</div>
          <div class="bm-keywords">
            Keywords found: <strong>${r.keyword_hits.join(', ') || 'none'}</strong>
          </div>
        </div>
      </div>`).join('');

    els.benchmarkResults.style.display = 'block';

  } catch (err) {
    showAlert(els.benchmarkError, `❌ ${err.message}`);
  } finally {
    hideLoader();
  }
});

// ── Export Tab ─────────────────────────────────────────────────────────────
function refreshExportTab() {
  if (state.chatHistory.length === 0) {
    els.exportEmpty.style.display   = 'flex';
    els.exportContent.style.display = 'none';
    return;
  }
  els.exportEmpty.style.display   = 'none';
  els.exportContent.style.display = 'block';
  els.exportCount.textContent = `${state.chatHistory.length} Q&A pair(s) ready to export.`;

  els.exportPreviewList.innerHTML = state.chatHistory.map((item, i) => `
    <div class="preview-item">
      <div class="preview-q">Q${i+1}: ${escHtml(item.question)}</div>
      <div class="preview-a">${escHtml(item.answer.slice(0, 120))}${item.answer.length > 120 ? '…' : ''}</div>
    </div>`).join('');
}

els.exportJsonBtn.addEventListener('click', () => {
  downloadFile(
    JSON.stringify(state.chatHistory, null, 2),
    `qa_history_${timestamp()}.json`,
    'application/json'
  );
  showToast('JSON downloaded!', 'success');
});

els.exportMdBtn.addEventListener('click', () => {
  const lines = [`# Document Q&A Session\n*Exported: ${new Date().toLocaleString()}*\n\n---\n`];
  state.chatHistory.forEach((item, i) => {
    lines.push(`## Q${i+1}: ${item.question}\n`);
    lines.push(`**Answer:** ${item.answer}\n\n`);
    if (item.sources?.length) {
      lines.push('**Sources:**\n');
      item.sources.forEach(s => lines.push(`- \`${s.source}\` — Chunk #${s.chunk_index}\n`));
    }
    lines.push('\n---\n');
  });
  downloadFile(lines.join(''), `qa_history_${timestamp()}.md`, 'text/markdown');
  showToast('Markdown downloaded!', 'success');
});

// ── Helpers ────────────────────────────────────────────────────────────────
function showLoader(text = 'Processing…') {
  els.loaderText.textContent = text;
  els.globalLoader.style.display = 'flex';
}
function hideLoader() {
  els.globalLoader.style.display = 'none';
}

function showAlert(el, msg) {
  el.textContent = msg;
  el.style.display = 'block';
}
function hideAlert(el) {
  el.style.display = 'none';
}

let toastTimer;
function showToast(msg, type = '') {
  clearTimeout(toastTimer);
  els.toast.textContent = msg;
  els.toast.className = `toast show ${type ? 'toast-' + type : ''}`;
  toastTimer = setTimeout(() => {
    els.toast.classList.remove('show');
  }, 3000);
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function downloadFile(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function timestamp() {
  return new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
}
