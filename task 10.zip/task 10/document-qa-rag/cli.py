"""
cli.py
------
Command-line interface for the Document Q&A RAG system.

Usage examples:
    # Single question
    python cli.py --file sample_data/sample.txt --question "What is ML?"

    # Interactive Q&A
    python cli.py --file sample_data/sample.txt

    # Conversational mode (with memory)
    python cli.py --file sample_data/sample.txt --mode conv

    # Summarize document
    python cli.py --file sample_data/sample.txt --summarize

    # Run benchmark
    python cli.py --file sample_data/sample.txt --benchmark

    # Export chat history
    python cli.py --file sample_data/sample.txt --export json
"""

import argparse
import os
from dotenv import load_dotenv

from src.document_loader import load_and_chunk
from src.vector_store import get_embeddings, get_or_build_store
from src.llm_provider import get_llm
from src.qa_chain import build_qa_chain, ask_question
from src.memory import build_conversational_chain, ask_with_memory, clear_memory
from src.summarizer import summarize_short, summarize_detailed, extract_key_topics, get_document_stats
from src.evaluator import run_benchmark, score_answer_confidence
from src.utils import export_chat_history, export_to_markdown, Timer

load_dotenv()

chat_history = []


def main():
    parser = argparse.ArgumentParser(description="Document Q&A RAG System")
    parser.add_argument("--file",      required=True,  help="Path to PDF, DOCX, or TXT")
    parser.add_argument("--question",  default=None,   help="Single question (omit for interactive)")
    parser.add_argument("--mode",      default="single", choices=["single", "conv"],
                        help="'single' = no memory, 'conv' = conversational with memory")
    parser.add_argument("--provider",  default="huggingface", choices=["huggingface", "openai"])
    parser.add_argument("--store",     default="faiss", choices=["faiss", "chroma"])
    parser.add_argument("--top-k",     type=int, default=4)
    parser.add_argument("--chunk-size",    type=int, default=500)
    parser.add_argument("--chunk-overlap", type=int, default=50)
    parser.add_argument("--summarize", action="store_true", help="Print document summary and exit")
    parser.add_argument("--benchmark", action="store_true", help="Run benchmark evaluation")
    parser.add_argument("--export",    default=None, choices=["json", "md"],
                        help="Export chat history format")
    args = parser.parse_args()

    if not os.path.exists(args.file):
        print(f"❌ File not found: {args.file}")
        return

    # ── Load & Index ──────────────────────────────────────────────────────────
    print(f"\n📄 Loading: {args.file}")
    with Timer("Load & chunk"):
        chunks = load_and_chunk(args.file, args.chunk_size, args.chunk_overlap)

    stats = get_document_stats(chunks)
    print(f"   Chunks: {stats['total_chunks']} | Est. words: {stats['estimated_words']:,}")

    print("🔢 Building embeddings...")
    with Timer("Embed"):
        embeddings = get_embeddings()
        vector_store = get_or_build_store(chunks, embeddings, args.store)

    print(f"🤖 Loading LLM ({args.provider})...")
    with Timer("LLM load"):
        llm = get_llm(args.provider)

    # ── Summarize mode ────────────────────────────────────────────────────────
    if args.summarize:
        print("\n📋 Generating summary...\n")
        print("=== SHORT SUMMARY ===")
        print(summarize_short(chunks, llm))
        print("\n=== KEY TOPICS ===")
        print(extract_key_topics(chunks, llm))
        return

    # ── Build chain ───────────────────────────────────────────────────────────
    if args.mode == "conv":
        print("🧠 Conversational mode (with memory)")
        chain = build_conversational_chain(vector_store, llm, args.top_k)
        ask_fn = lambda q: ask_with_memory(chain, q)
    else:
        print("🔍 Single Q&A mode")
        chain = build_qa_chain(vector_store, llm, args.top_k)
        ask_fn = lambda q: ask_question(chain, q)

    # ── Benchmark mode ────────────────────────────────────────────────────────
    if args.benchmark:
        single_chain = build_qa_chain(vector_store, llm, args.top_k)
        run_benchmark(single_chain)
        return

    print("\n✅ System ready!\n")

    # ── Single question ───────────────────────────────────────────────────────
    if args.question:
        result = _run_query(ask_fn, args.question)
        chat_history.append(result)
    else:
        # ── Interactive mode ──────────────────────────────────────────────────
        print("💬 Interactive mode — type 'quit' to exit, 'clear' to reset memory\n")
        while True:
            try:
                question = input("Your question: ").strip()
            except (KeyboardInterrupt, EOFError):
                break

            if question.lower() in ("quit", "exit", "q"):
                break
            if question.lower() == "clear":
                if args.mode == "conv":
                    clear_memory(chain)
                chat_history.clear()
                print("Memory cleared.\n")
                continue
            if not question:
                continue

            result = _run_query(ask_fn, question)
            chat_history.append(result)

    # ── Export ────────────────────────────────────────────────────────────────
    if args.export and chat_history:
        if args.export == "json":
            export_chat_history(chat_history)
        elif args.export == "md":
            export_to_markdown(chat_history)

    print("\nGoodbye!")


def _run_query(ask_fn, question: str) -> dict:
    """Run a single query, print results, return the record."""
    print(f"\n🔍 Question: {question}")

    with Timer("Answer"):
        result = ask_fn(question)

    confidence = score_answer_confidence(result["answer"], result["sources"])

    print(f"\n💡 Answer:\n{result['answer']}")
    print(f"\n📊 Confidence: {confidence['label']} ({confidence['score']}/100)")

    if confidence["flags"]:
        for flag in confidence["flags"]:
            print(f"   ⚠️  {flag}")

    print(f"\n📎 Sources ({len(result['sources'])} chunks):")
    for i, src in enumerate(result["sources"]):
        relevance = src.get("relevance_pct", "?")
        print(f"  [{i+1}] {src['source']} — Chunk #{src['chunk_index']} — Relevance: {relevance}%")
        print(f"       {src['chunk'][:120]}...")

    print("-" * 60)

    return {
        "question": question,
        "answer": result["answer"],
        "sources": result["sources"],
        "confidence": confidence
    }


if __name__ == "__main__":
    main()
