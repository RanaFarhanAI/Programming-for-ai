-- ============================================================
-- AI Career Coach — SQL Server Schema
-- Run this in SSMS to set up the database manually if needed
-- SQLAlchemy will also auto-create these via db.create_all()
-- ============================================================

USE master;
GO

-- Create database if it doesn't exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'ai_career_coach')
BEGIN
    CREATE DATABASE ai_career_coach;
END
GO

USE ai_career_coach;
GO

-- ── Users Table ───────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' AND xtype='U')
BEGIN
    CREATE TABLE users (
        id          INT IDENTITY(1,1) PRIMARY KEY,
        username    NVARCHAR(80)  NOT NULL UNIQUE,
        email       NVARCHAR(120) NOT NULL UNIQUE,
        password    NVARCHAR(255) NOT NULL,
        created_at  DATETIME2     NOT NULL DEFAULT GETUTCDATE()
    );
END
GO

-- ── Chat Sessions Table ──────────────────────────────────────────────────────
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='chat_sessions' AND xtype='U')
BEGIN
    CREATE TABLE chat_sessions (
        id         INT IDENTITY(1,1) PRIMARY KEY,
        user_id    INT           NOT NULL,
        title      NVARCHAR(120) NOT NULL DEFAULT 'New Chat',
        created_at DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
        updated_at DATETIME2     NOT NULL DEFAULT GETUTCDATE(),

        CONSTRAINT fk_session_user FOREIGN KEY (user_id)
            REFERENCES users(id) ON DELETE CASCADE
    );
END
GO

-- ── Chat Messages Table ───────────────────────────────────────────────────────
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='chat_messages' AND xtype='U')
BEGIN
    CREATE TABLE chat_messages (
        id          INT IDENTITY(1,1) PRIMARY KEY,
        user_id     INT           NOT NULL,
        session_id  INT           NULL,
        role        NVARCHAR(10)  NOT NULL CHECK (role IN ('user', 'assistant')),
        content     NVARCHAR(MAX) NOT NULL,
        created_at  DATETIME2     NOT NULL DEFAULT GETUTCDATE(),

        CONSTRAINT fk_chat_user    FOREIGN KEY (user_id)
            REFERENCES users(id) ON DELETE CASCADE,
        CONSTRAINT fk_chat_session FOREIGN KEY (session_id)
            REFERENCES chat_sessions(id) ON DELETE NO ACTION
    );
END
GO

-- ── Indexes for performance ───────────────────────────────────────────────────
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_session_user_id')
    CREATE INDEX idx_session_user_id ON chat_sessions(user_id);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_session_updated_at')
    CREATE INDEX idx_session_updated_at ON chat_sessions(updated_at);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_chat_user_id')
    CREATE INDEX idx_chat_user_id ON chat_messages(user_id);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_chat_session_id')
    CREATE INDEX idx_chat_session_id ON chat_messages(session_id);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_chat_created_at')
    CREATE INDEX idx_chat_created_at ON chat_messages(created_at);
GO

PRINT 'Schema created successfully.';
GO
