from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager

# Extensions — initialized here, bound to app in app.py
db = SQLAlchemy(session_options={"expire_on_commit": False})
bcrypt = Bcrypt()
login_manager = LoginManager()

# ── Models ────────────────────────────────────────────────────────────────────

from flask_login import UserMixin
from datetime import datetime


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id         = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.String(80),  unique=True, nullable=False)
    email      = db.Column(db.String(120), unique=True, nullable=False)
    password   = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # relationships
    messages  = db.relationship("ChatMessage", backref="user",    lazy=True, cascade="all, delete-orphan")
    sessions  = db.relationship("ChatSession", backref="user",    lazy=True, cascade="all, delete-orphan")

    def set_password(self, raw_password):
        self.password = bcrypt.generate_password_hash(raw_password).decode("utf-8")

    def check_password(self, raw_password):
        return bcrypt.check_password_hash(self.password, raw_password)

    def __repr__(self):
        return f"<User {self.username}>"


class ChatSession(db.Model):
    __tablename__ = "chat_sessions"

    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title      = db.Column(db.String(120), nullable=False, default="New Chat")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    messages   = db.relationship("ChatMessage", backref="session", lazy=True,
                                 cascade="all, delete-orphan",
                                 order_by="ChatMessage.created_at")

    def to_dict(self):
        return {
            "id":         self.id,
            "title":      self.title,
            "created_at": self.created_at.strftime("%b %d, %H:%M"),
            "updated_at": self.updated_at.strftime("%b %d, %H:%M") if self.updated_at else "",
            "msg_count":  len(self.messages)
        }

    def __repr__(self):
        return f"<ChatSession {self.id} | user={self.user_id}>"


class ChatMessage(db.Model):
    __tablename__ = "chat_messages"

    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey("users.id"),     nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey("chat_sessions.id"), nullable=True)
    role       = db.Column(db.String(10), nullable=False)   # 'user' or 'assistant'
    content    = db.Column(db.Text,       nullable=False)
    created_at = db.Column(db.DateTime,  default=datetime.utcnow)

    def to_dict(self):
        return {
            "role":       self.role,
            "content":    self.content,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M")
        }

    def __repr__(self):
        return f"<ChatMessage {self.role} | user={self.user_id}>"
