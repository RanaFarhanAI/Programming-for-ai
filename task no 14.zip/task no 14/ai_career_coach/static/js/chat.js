// ── Marked config ─────────────────────────────────────────────────────────────
marked.setOptions({ breaks: true, gfm: true });

// ── State ─────────────────────────────────────────────────────────────────────
let activeSessionId = document.getElementById("activeSessionId")?.value || null;
let isStreaming     = false;

// ── DOM refs ──────────────────────────────────────────────────────────────────
const chatMessages    = document.getElementById("chatMessages");
const messageInput    = document.getElementById("messageInput");
const sendBtn         = document.getElementById("sendBtn");
const typingIndicator = document.getElementById("typingIndicator");
const charCount       = document.getElementById("charCount");
const headerTitle     = document.getElementById("chatHeaderTitle");

// ── Init: render existing markdown messages ───────────────────────────────────
document.querySelectorAll('[data-markdown="true"]').forEach(el => {
  el.innerHTML = marked.parse(el.textContent);
  el.querySelectorAll("pre code").forEach(b => hljs.highlightElement(b));
  addCopyButtons(el);
});
scrollToBottom();
messageInput?.focus();

// ── Send message (streaming) ──────────────────────────────────────────────────
async function sendMessage() {
  const text = messageInput.value.trim();
  if (!text || isStreaming) return;

  document.getElementById("welcomeMsg")?.remove();

  appendMessage("user", text);
  messageInput.value = "";
  autoResize(messageInput);
  updateCharCount(messageInput);

  setInputState(false);
  showTyping(true);
  scrollToBottom();

  try {
    const res = await fetch("/api/chat/stream", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ message: text, session_id: activeSessionId || null }),
    });

    if (!res.ok) throw new Error("Server error");

    showTyping(false);
    const aiWrapper = appendStreamingMessage();
    const contentEl = aiWrapper.querySelector(".msg-content");

    isStreaming  = true;
    let fullText = "";

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop(); // keep incomplete line

      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        try {
          const payload = JSON.parse(line.slice(6));

          if (payload.type === "session") {
            activeSessionId = payload.session_id;
            document.getElementById("activeSessionId").value = activeSessionId;
            updateSessionTitle(payload.session_id, payload.title);
            updateHeaderTitle(payload.title);
          }

          if (payload.type === "chunk") {
            fullText += payload.text;
            contentEl.innerHTML = marked.parse(fullText);
            contentEl.querySelectorAll("pre code").forEach(b => hljs.highlightElement(b));
            addCopyButtons(contentEl);
            scrollToBottom();
          }

          if (payload.type === "done") {
            finalizeStreamMessage(aiWrapper, fullText);
          }

          if (payload.type === "error") {
            contentEl.innerHTML = `<span style="color:var(--danger)">${payload.text}</span>`;
          }
        } catch (_) { /* skip malformed lines */ }
      }
    }

  } catch (err) {
    showTyping(false);
    appendMessage("assistant", "Network error. Please check your connection and try again.");
    showToast("Connection error. Please try again.", "danger");
  } finally {
    isStreaming = false;
    setInputState(true);
    scrollToBottom();
    messageInput.focus();
  }
}

// ── Quick prompts ─────────────────────────────────────────────────────────────
function sendQuick(text) {
  messageInput.value = text;
  updateCharCount(messageInput);
  sendMessage();
}

// ── Session management ────────────────────────────────────────────────────────
async function newChat() {
  try {
    const res  = await fetch("/chat/new", { method: "POST" });
    const data = await res.json();

    activeSessionId = data.session_id;
    document.getElementById("activeSessionId").value = activeSessionId;

    // Add to sessions list
    addSessionToSidebar(data.session_id, data.title, true);
    updateHeaderTitle("New Chat");

    // Clear messages area
    chatMessages.innerHTML = `
      <div class="welcome-msg" id="welcomeMsg">
        <div class="welcome-icon"><i class="fa-solid fa-robot"></i></div>
        <h3>New conversation started</h3>
        <p>What would you like to talk about?</p>
      </div>`;

    // Remove empty state if present
    document.getElementById("emptySessions")?.remove();

    // Close sidebar on mobile
    if (window.innerWidth < 768) toggleSidebar(false);

    messageInput.focus();
  } catch (err) {
    showToast("Failed to create new chat.", "danger");
  }
}

function loadSession(sessionId) {
  window.location.href = `/chat/${sessionId}`;
}

async function deleteSession(sessionId) {
  if (!confirm("Delete this conversation?")) return;
  try {
    await fetch(`/chat/session/${sessionId}/delete`, { method: "POST" });
    document.getElementById(`session-${sessionId}`)?.remove();

    if (String(activeSessionId) === String(sessionId)) {
      // Navigate to chat root to pick next session
      window.location.href = "/chat";
    }
    showToast("Conversation deleted.", "info");
  } catch (err) {
    showToast("Failed to delete conversation.", "danger");
  }
}

async function renameSession(sessionId) {
  const titleEl  = document.getElementById(`title-${sessionId}`);
  const oldTitle = titleEl?.textContent || "";
  const newTitle = prompt("Rename conversation:", oldTitle);
  if (!newTitle || newTitle === oldTitle) return;

  try {
    const res  = await fetch(`/chat/session/${sessionId}/rename`, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ title: newTitle }),
    });
    const data = await res.json();
    if (titleEl) titleEl.textContent = data.title;
    if (String(activeSessionId) === String(sessionId)) {
      updateHeaderTitle(data.title);
    }
    showToast("Conversation renamed.", "success");
  } catch (err) {
    showToast("Failed to rename.", "danger");
  }
}

async function clearCurrentChat() {
  if (!confirm("Clear messages in this conversation?")) return;
  try {
    await fetch("/api/chat/clear", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ session_id: activeSessionId }),
    });
    chatMessages.innerHTML = `
      <div class="welcome-msg" id="welcomeMsg">
        <div class="welcome-icon"><i class="fa-solid fa-robot"></i></div>
        <h3>Chat cleared!</h3>
        <p>Start a new conversation below.</p>
      </div>`;
    showToast("Chat cleared.", "success");
  } catch (err) {
    showToast("Failed to clear chat.", "danger");
  }
}

// ── Sidebar toggle (mobile) ───────────────────────────────────────────────────
function toggleSidebar(forceState) {
  const sidebar = document.getElementById("chatSidebar");
  const overlay = document.getElementById("sidebarOverlay");
  const isOpen  = sidebar.classList.contains("open");
  const open    = forceState !== undefined ? forceState : !isOpen;

  sidebar.classList.toggle("open", open);
  overlay.classList.toggle("active", open);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function appendMessage(role, content) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;
  const time = now();

  if (role === "assistant") {
    const parsed = marked.parse(content);
    wrapper.innerHTML = `
      <div class="msg-avatar ai-avatar"><i class="fa-solid fa-robot"></i></div>
      <div class="msg-bubble">
        <div class="msg-content">${parsed}</div>
        <div class="msg-meta">
          <div class="msg-time">${time}</div>
          <button class="copy-msg-btn" title="Copy" onclick="copyMessage(this)">
            <i class="fa-regular fa-copy"></i>
          </button>
        </div>
      </div>`;
    wrapper.querySelectorAll("pre code").forEach(b => hljs.highlightElement(b));
    addCopyButtons(wrapper.querySelector(".msg-content"));
  } else {
    wrapper.innerHTML = `
      <div class="msg-bubble">
        <div class="msg-content">${escapeHtml(content)}</div>
        <div class="msg-time">${time}</div>
      </div>
      <div class="msg-avatar user-avatar"><i class="fa-solid fa-user"></i></div>`;
  }

  chatMessages.appendChild(wrapper);
  return wrapper;
}

function appendStreamingMessage() {
  const wrapper = document.createElement("div");
  wrapper.className = "message assistant streaming";
  wrapper.innerHTML = `
    <div class="msg-avatar ai-avatar"><i class="fa-solid fa-robot"></i></div>
    <div class="msg-bubble">
      <div class="msg-content"></div>
      <div class="msg-meta">
        <div class="msg-time">${now()}</div>
        <button class="copy-msg-btn" title="Copy" onclick="copyMessage(this)">
          <i class="fa-regular fa-copy"></i>
        </button>
      </div>
    </div>`;
  chatMessages.appendChild(wrapper);
  return wrapper;
}

function finalizeStreamMessage(wrapper, fullText) {
  wrapper.classList.remove("streaming");
  const contentEl = wrapper.querySelector(".msg-content");
  contentEl.innerHTML = marked.parse(fullText);
  contentEl.querySelectorAll("pre code").forEach(b => hljs.highlightElement(b));
  addCopyButtons(contentEl);
}

function addCopyButtons(container) {
  container.querySelectorAll("pre").forEach(pre => {
    if (pre.querySelector(".copy-code-btn")) return;
    const btn       = document.createElement("button");
    btn.className   = "copy-code-btn";
    btn.title       = "Copy code";
    btn.innerHTML   = '<i class="fa-regular fa-copy"></i>';
    btn.addEventListener("click", () => {
      const code = pre.querySelector("code")?.innerText || "";
      navigator.clipboard.writeText(code).then(() => {
        btn.innerHTML = '<i class="fa-solid fa-check"></i>';
        setTimeout(() => { btn.innerHTML = '<i class="fa-regular fa-copy"></i>'; }, 2000);
      });
    });
    pre.style.position = "relative";
    pre.appendChild(btn);
  });
}

function copyMessage(btn) {
  const text = btn.closest(".msg-bubble").querySelector(".msg-content").innerText;
  navigator.clipboard.writeText(text).then(() => {
    btn.innerHTML = '<i class="fa-solid fa-check"></i>';
    showToast("Copied to clipboard!", "success");
    setTimeout(() => { btn.innerHTML = '<i class="fa-regular fa-copy"></i>'; }, 2000);
  });
}

function addSessionToSidebar(id, title, setActive = false) {
  const list = document.getElementById("sessionsList");
  // Remove active from all
  list.querySelectorAll(".session-item").forEach(el => el.classList.remove("active"));

  const item = document.createElement("div");
  item.className = `session-item${setActive ? " active" : ""}`;
  item.id        = `session-${id}`;
  item.onclick   = () => loadSession(id);
  item.innerHTML = `
    <div class="session-item-body">
      <i class="fa-regular fa-comment"></i>
      <span class="session-title" id="title-${id}">${escapeHtml(title)}</span>
    </div>
    <div class="session-actions">
      <button class="session-btn" title="Rename"
              onclick="event.stopPropagation(); renameSession(${id})">
        <i class="fa-solid fa-pen"></i>
      </button>
      <button class="session-btn danger" title="Delete"
              onclick="event.stopPropagation(); deleteSession(${id})">
        <i class="fa-solid fa-trash"></i>
      </button>
    </div>`;

  // Insert after label
  const label = list.querySelector(".sidebar-label");
  label ? label.after(item) : list.prepend(item);
}

function updateSessionTitle(id, title) {
  const el = document.getElementById(`title-${id}`);
  if (el) el.textContent = title;

  // If session not in list yet, add it
  if (!document.getElementById(`session-${id}`)) {
    addSessionToSidebar(id, title, true);
  }
}

function updateHeaderTitle(title) {
  if (headerTitle) headerTitle.textContent = title;
  document.title = `${title} — AI Career Coach`;
}

// ── Toast notifications ───────────────────────────────────────────────────────
function showToast(message, type = "info") {
  const container = getOrCreateToastContainer();
  const toast     = document.createElement("div");
  toast.className = `toast toast-${type}`;

  const icons = { success: "fa-circle-check", danger: "fa-circle-xmark", info: "fa-circle-info" };
  toast.innerHTML = `
    <i class="fa-solid ${icons[type] || icons.info}"></i>
    <span>${escapeHtml(message)}</span>
    <button onclick="this.parentElement.remove()">×</button>`;

  container.appendChild(toast);
  // Animate in
  requestAnimationFrame(() => toast.classList.add("show"));
  // Auto-remove after 3.5s
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function getOrCreateToastContainer() {
  let c = document.getElementById("toastContainer");
  if (!c) {
    c = document.createElement("div");
    c.id        = "toastContainer";
    c.className = "toast-container";
    document.body.appendChild(c);
  }
  return c;
}

// ── Utilities ─────────────────────────────────────────────────────────────────
function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function now() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function showTyping(show) {
  typingIndicator.style.display = show ? "flex" : "none";
}

function setInputState(enabled) {
  messageInput.disabled = !enabled;
  sendBtn.disabled      = !enabled;
  sendBtn.style.opacity = enabled ? "1" : "0.5";
}

function scrollToBottom() {
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function autoResize(el) {
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 140) + "px";
}

function updateCharCount(el) {
  const len  = el.value.length;
  const max  = el.maxLength || 4000;
  if (charCount) {
    charCount.textContent = `${len} / ${max}`;
    charCount.style.color = len > max * 0.9 ? "var(--danger)" : "var(--text-muted)";
  }
}

function handleKey(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}
