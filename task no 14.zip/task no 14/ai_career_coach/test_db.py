"""
Run this script AFTER starting SQL Server service.
It will tell you exactly which server name to put in your .env file.

Usage:
    python test_db.py
"""
import pyodbc
import os
import socket

machine = socket.gethostname()

servers = [
    "localhost",
    f"{machine}\\SQLEXPRESS",
    f"{machine}\\MSSQLSERVER",
    f"localhost\\SQLEXPRESS",
    f"localhost\\MSSQLSERVER",
    f".\\SQLEXPRESS",
    "(local)",
    "127.0.0.1",
]

print(f"Machine name: {machine}")
print("=" * 60)
print("Testing SQL Server connections...\n")

found = False
for server in servers:
    try:
        conn_str = (
            f"DRIVER={{SQL Server}};"
            f"SERVER={server};"
            f"DATABASE=master;"
            f"Trusted_Connection=yes;"
        )
        conn = pyodbc.connect(conn_str, timeout=3)
        print(f"✓ SUCCESS: '{server}' works!")
        print(f"\n  Put this in your .env file:")
        print(f"  DB_SERVER={server}\n")
        conn.close()
        found = True
        break
    except Exception as e:
        print(f"✗ FAILED:  '{server}'")

if not found:
    print("\n" + "=" * 60)
    print("No connection worked. SQL Server is likely not running.")
    print("\nFix: Press Win+R → type 'services.msc' → find 'SQL Server'")
    print("     → right-click → Start")
    print("\nThen run this script again.")
