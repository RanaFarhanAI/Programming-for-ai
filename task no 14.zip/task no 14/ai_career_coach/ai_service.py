import time
from groq import Groq
from config import Config

# Groq client
client = Groq(api_key=Config.GROQ_API_KEY)

# Model — llama-3.3-70b is the best free model on Groq
MODEL = "llama-3.3-70b-versatile"

# System prompt — defines the AI persona
SYSTEM_PROMPT = """
You are an expert AI Career Coach and Mentor. Your role is to:
- Help users with career guidance, roadmaps, and goal setting
- Assist with coding problems across all languages and frameworks
- Explain concepts in physics, math, and other academic subjects clearly
- Provide resume tips, interview preparation, and soft skills advice
- Motivate and support users through their learning journey

Always be:
- Clear and concise in explanations
- Encouraging and supportive
- Practical — give real examples, code snippets, or step-by-step plans
- Honest — if something is hard, say so and guide them through it

Format code blocks properly using markdown when sharing code.
"""


def build_history(messages) -> list:
    """
    Convert DB ChatMessage objects into Groq/OpenAI message format.
    """
    history = []
    for msg in messages:
        role = "assistant" if msg.role == "assistant" else "user"
        history.append({"role": role, "content": msg.content})
    return history


def get_ai_response(conversation_history: list) -> str:
    """
    Send full conversation history to Groq and return the complete reply.
    Retries once on rate limit errors.
    """
    for attempt in range(2):
        try:
            if not conversation_history:
                return "Please send a message to get started."

            messages = [{"role": "system", "content": SYSTEM_PROMPT}] + conversation_history

            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                temperature=0.7,
                max_tokens=2048,
            )
            return response.choices[0].message.content or "I couldn't generate a response. Please try again."

        except Exception as e:
            err = str(e)
            if "429" in err and attempt == 0:
                time.sleep(5)
                continue
            if "429" in err:
                return "⚠️ Rate limit reached. Please wait a moment and try again."
            return f"Sorry, I encountered an error: {err[:200]}. Please try again."


def get_ai_response_stream(conversation_history: list):
    """
    Generator that yields text chunks from Groq for streaming responses.
    """
    try:
        if not conversation_history:
            yield "Please send a message to get started."
            return

        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + conversation_history

        stream = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            temperature=0.7,
            max_tokens=2048,
            stream=True,
        )

        for chunk in stream:
            text = chunk.choices[0].delta.content
            if text:
                yield text

    except Exception as e:
        err = str(e)
        if "429" in err:
            yield "⚠️ Rate limit reached. Please wait a moment and try again."
        else:
            yield f"Sorry, I encountered an error: {err[:200]}. Please try again."
