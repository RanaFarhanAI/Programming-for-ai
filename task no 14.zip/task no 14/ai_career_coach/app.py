from flask import (Flask, render_template, request, redirect,
                   url_for, jsonify, flash, Response, stream_with_context)
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime, timezone, timedelta
from config import Config
from database import db, bcrypt, login_manager, User, ChatSession, ChatMessage
from ai_service import get_ai_response, get_ai_response_stream, build_history

# ── App Factory ───────────────────────────────────────────────────────────────

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "login"
    login_manager.login_message_category = "info"

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    with app.app_context():
        db.create_all()

    return app


app = create_app()


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_or_create_session(session_id=None):
    """Return an existing ChatSession or create a new one."""
    if session_id:
        s = ChatSession.query.filter_by(id=session_id, user_id=current_user.id).first()
        if s:
            return s
    # Create fresh session
    s = ChatSession(user_id=current_user.id, title="New Chat")
    db.session.add(s)
    db.session.commit()
    return s


def auto_title(session, first_message: str):
    """Set session title from first user message (truncated)."""
    if session.title == "New Chat":
        session.title = first_message[:60].strip()
        db.session.commit()


# ── Landing ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


# ── Dashboard ─────────────────────────────────────────────────────────────────

@app.route("/dashboard")
@login_required
def dashboard():
    total_messages = ChatMessage.query.filter_by(user_id=current_user.id).count()
    ai_responses   = ChatMessage.query.filter_by(user_id=current_user.id, role="assistant").count()

    delta       = datetime.now(timezone.utc) - current_user.created_at.replace(tzinfo=timezone.utc)
    days_active = max(delta.days, 1)

    week_ago     = datetime.now(timezone.utc) - timedelta(days=7)
    recent_count = ChatMessage.query.filter(
        ChatMessage.user_id == current_user.id,
        ChatMessage.created_at >= week_ago
    ).count()

    recent_messages = (
        ChatMessage.query
        .filter_by(user_id=current_user.id)
        .order_by(ChatMessage.created_at.desc())
        .limit(8).all()
    )
    recent_messages.reverse()

    return render_template(
        "dashboard.html",
        total_messages  = total_messages,
        ai_responses    = ai_responses,
        days_active     = days_active,
        recent_count    = recent_count,
        recent_messages = recent_messages,
    )


# ── Auth ──────────────────────────────────────────────────────────────────────

@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email    = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not username or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("register.html")
        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "danger")
            return render_template("register.html")
        if User.query.filter_by(username=username).first():
            flash("Username already taken.", "danger")
            return render_template("register.html")

        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Account created! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email    = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        user     = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            login_user(user)
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


# ── Chat ──────────────────────────────────────────────────────────────────────

@app.route("/chat")
@app.route("/chat/<int:session_id>")
@login_required
def chat(session_id=None):
    # Load all user sessions for sidebar
    all_sessions = (
        ChatSession.query
        .filter_by(user_id=current_user.id)
        .order_by(ChatSession.updated_at.desc())
        .all()
    )

    # Resolve active session
    active_session = None
    messages       = []

    if session_id:
        active_session = ChatSession.query.filter_by(
            id=session_id, user_id=current_user.id
        ).first_or_404()
        messages = active_session.messages
    elif all_sessions:
        # Default to most recent
        active_session = all_sessions[0]
        messages       = active_session.messages

    return render_template(
        "chat.html",
        messages        = messages,
        all_sessions    = all_sessions,
        active_session  = active_session,
    )


@app.route("/chat/new", methods=["POST"])
@login_required
def new_chat():
    s = ChatSession(user_id=current_user.id, title="New Chat")
    db.session.add(s)
    db.session.commit()
    return jsonify({"session_id": s.id, "title": s.title})


@app.route("/chat/session/<int:session_id>/delete", methods=["POST"])
@login_required
def delete_session(session_id):
    s = ChatSession.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()
    db.session.delete(s)
    db.session.commit()
    return jsonify({"status": "deleted"})


@app.route("/chat/session/<int:session_id>/rename", methods=["POST"])
@login_required
def rename_session(session_id):
    s     = ChatSession.query.filter_by(id=session_id, user_id=current_user.id).first_or_404()
    title = request.get_json().get("title", "").strip()
    if title:
        s.title = title[:60]
        db.session.commit()
    return jsonify({"title": s.title})


# ── Chat API (streaming) ──────────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():
    data         = request.get_json()
    user_message = data.get("message", "").strip()
    session_id   = data.get("session_id")

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    # Resolve session
    chat_session = get_or_create_session(session_id)

    # Save user message
    user_msg = ChatMessage(
        user_id    = current_user.id,
        session_id = chat_session.id,
        role       = "user",
        content    = user_message
    )
    db.session.add(user_msg)
    db.session.commit()

    # Auto-title from first message
    auto_title(chat_session, user_message)

    # Build history from this session only
    history  = build_history(chat_session.messages)
    ai_reply = get_ai_response(history)

    # Save AI response
    ai_msg = ChatMessage(
        user_id    = current_user.id,
        session_id = chat_session.id,
        role       = "assistant",
        content    = ai_reply
    )
    db.session.add(ai_msg)

    # Update session timestamp
    chat_session.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({
        "reply":      ai_reply,
        "session_id": chat_session.id,
        "title":      chat_session.title
    })


@app.route("/api/chat/stream", methods=["POST"])
@login_required
def api_chat_stream():
    """Server-Sent Events streaming endpoint."""
    data         = request.get_json()
    user_message = data.get("message", "").strip()
    session_id   = data.get("session_id")

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    chat_session = get_or_create_session(session_id)

    user_msg = ChatMessage(
        user_id    = current_user.id,
        session_id = chat_session.id,
        role       = "user",
        content    = user_message
    )
    db.session.add(user_msg)
    db.session.commit()
    auto_title(chat_session, user_message)

    history = build_history(chat_session.messages)

    def generate():
        full_reply = ""
        try:
            # Send session info first
            import json
            yield f"data: {json.dumps({'type': 'session', 'session_id': chat_session.id, 'title': chat_session.title})}\n\n"

            for chunk in get_ai_response_stream(history):
                full_reply += chunk
                yield f"data: {json.dumps({'type': 'chunk', 'text': chunk})}\n\n"

            # Save complete response
            ai_msg = ChatMessage(
                user_id    = current_user.id,
                session_id = chat_session.id,
                role       = "assistant",
                content    = full_reply
            )
            db.session.add(ai_msg)
            chat_session.updated_at = datetime.utcnow()
            db.session.commit()

            yield f"data: {json.dumps({'type': 'done'})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'text': str(e)})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control":   "no-cache",
            "X-Accel-Buffering": "no"
        }
    )


@app.route("/api/chat/clear", methods=["POST"])
@login_required
def clear_chat():
    session_id = request.get_json(silent=True) or {}
    sid = session_id.get("session_id") if isinstance(session_id, dict) else None
    if sid:
        ChatMessage.query.filter_by(session_id=sid, user_id=current_user.id).delete()
    else:
        ChatMessage.query.filter_by(user_id=current_user.id).delete()
    db.session.commit()
    return jsonify({"status": "cleared"})


@app.route("/api/chat/export")
@login_required
def export_chat():
    messages = (
        ChatMessage.query
        .filter_by(user_id=current_user.id)
        .order_by(ChatMessage.created_at.asc())
        .all()
    )
    return jsonify({"messages": [m.to_dict() for m in messages]})


# ── Profile & Settings ────────────────────────────────────────────────────────

@app.route("/profile")
@login_required
def profile():
    total_messages = ChatMessage.query.filter_by(user_id=current_user.id).count()
    ai_responses   = ChatMessage.query.filter_by(user_id=current_user.id, role="assistant").count()
    return render_template("profile.html",
                           total_messages=total_messages,
                           ai_responses=ai_responses)


@app.route("/profile/update", methods=["POST"])
@login_required
def update_profile():
    form_type = request.form.get("form_type")

    if form_type == "profile":
        username = request.form.get("username", "").strip()
        email    = request.form.get("email", "").strip()

        if not username or not email:
            flash("Username and email are required.", "danger")
            return redirect(url_for("profile"))

        if User.query.filter(User.username == username, User.id != current_user.id).first():
            flash("Username already taken.", "danger")
            return redirect(url_for("profile"))
        if User.query.filter(User.email == email, User.id != current_user.id).first():
            flash("Email already in use.", "danger")
            return redirect(url_for("profile"))

        current_user.username = username
        current_user.email    = email
        db.session.commit()
        flash("Profile updated successfully.", "success")

    elif form_type == "password":
        current_pw = request.form.get("current_password", "")
        new_pw     = request.form.get("new_password", "")
        confirm_pw = request.form.get("confirm_password", "")

        if not current_user.check_password(current_pw):
            flash("Current password is incorrect.", "danger")
            return redirect(url_for("profile"))
        if len(new_pw) < 6:
            flash("New password must be at least 6 characters.", "danger")
            return redirect(url_for("profile"))
        if new_pw != confirm_pw:
            flash("New passwords do not match.", "danger")
            return redirect(url_for("profile"))

        current_user.set_password(new_pw)
        db.session.commit()
        flash("Password updated successfully.", "success")

    return redirect(url_for("profile"))


@app.route("/profile/delete", methods=["POST"])
@login_required
def delete_account():
    user_id = current_user.id
    logout_user()
    user = db.session.get(User, user_id)
    if user:
        db.session.delete(user)
        db.session.commit()
    flash("Your account has been deleted.", "info")
    return redirect(url_for("index"))


# ── Error Handlers ────────────────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404

@app.errorhandler(500)
def server_error(e):
    return render_template("500.html"), 500


# ── Run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=Config.DEBUG)
