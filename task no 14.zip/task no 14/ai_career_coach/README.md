# AI Career Coach

An AI-powered career mentorship chatbot built with Flask, Google Gemini, and SQL Server.

## Features
- AI chatbot powered by Gemini 1.5 Flash with full conversation memory
- Career roadmaps, coding help, physics/math support, interview prep
- User authentication (register/login) with bcrypt password hashing
- Persistent chat history stored in SQL Server
- Dashboard with usage stats and quick actions
- Dark, responsive UI with markdown + syntax highlighting

## Tech Stack
- **Backend:** Python, Flask, SQLAlchemy
- **AI:** Google Generative AI (Gemini 1.5 Flash)
- **Database:** SQL Server (via pyodbc + ODBC Driver 17)
- **Frontend:** Jinja2 templates, vanilla JS, highlight.js, marked.js

## Setup

### 1. Prerequisites
- Python 3.10+
- SQL Server + SSMS installed
- ODBC Driver 17 for SQL Server
- Google Gemini API key ([get one here](https://aistudio.google.com/))

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set up the database
Open SSMS and run `database/schema.sql` to create the database and tables.

### 4. Configure environment
Edit `.env` with your credentials:
```
SECRET_KEY=your_random_secret_key
GEMINI_API_KEY=your_gemini_api_key
DB_SERVER=localhost
DB_NAME=ai_career_coach
DB_USERNAME=your_sql_username
DB_PASSWORD=your_sql_password
```

### 5. Run the app
```bash
python run.py
```

Open `http://localhost:5000` in your browser.

## Project Structure
```
ai_career_coach/
├── static/
│   ├── css/style.css
│   └── js/chat.js
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── chat.html
│   ├── 404.html
│   └── 500.html
├── database/
│   └── schema.sql
├── app.py
├── ai_service.py
├── database.py
├── config.py
├── run.py
└── .env
```
