import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Flask
    SECRET_KEY = os.getenv("SECRET_KEY", "fallback_secret_key")
    DEBUG = os.getenv("FLASK_DEBUG", "False") == "True"

    # Gemini AI (kept for reference)
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

    # Groq AI
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")

    # SQLite — zero setup, database file created automatically
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "ai_career_coach.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
